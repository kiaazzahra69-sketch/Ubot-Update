import asyncio
import random
import time
import re


from pyrogram import enums, errors

from openai import AsyncOpenAI
import config
from clients import session
from database import dB
from helpers import (MessageFilter, Emoji, Tools, get_cached_list, reply_same_type,
                     url_mmk)


userbot_ids = set()

blacklisted_chats = set()

DEFAULT_ROLE = "Kamu adalah member grup biasa yang super santai, sering nyelamur, dan sok akrab. Kamu tahu semua bahasa gaul. Jawabanmu harus sangat luwes seperti teman akrab, tidak kaku, dan tidak lebih dari 10 karakter. JANGAN PERNAH mengaku sebagai AI, bot, atau chatbot. JANGAN gunakan emoji atau tanda baca. JANGAN PERNAH memberi bantuan apapun."

OPENAI_API_KEY = "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"

openai_client = AsyncOpenAI(api_key=OPENAI_API_KEY)


async def gen_text(client, message):
    text = (message.text or message.caption).strip()
    if not text:
        return

    role = await dB.get_var(client.me.id, "ROLE_CHATBOT") or DEFAULT_ROLE

    try:
        response = await openai_client.chat.completions.create(
            model="gpt-3.5-turbo",   # bisa ganti ke "gpt-4o-mini" kalau API key mendukung
            messages=[
                {"role": "system", "content": role},
                {"role": "user", "content": text},
            ],
            max_tokens=200,
            temperature=0.7,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print("OpenAI Error:", e)
        return None


async def get_random_text():
    return await dB.get_var(config.BOT_ID, "CHATBOT_TEXT") or []


async def add_auto_text(text):
    auto_text = await get_random_text()
    auto_text.append(text)
    await dB.set_var(config.BOT_ID, "CHATBOT_TEXT", auto_text)


async def chatbot_cmd(client, message):
    em = Emoji(client)
    await em.get()
    if len(message.command) < 2:
        return await message.reply(
            f"<blockquote>{em.gagal}<b>Usage: `{message.text.split()[0]} on | off | status | role | ignoreadmin | reignoreadmin | auto`</b></blockquote>"
        )

    cmd = message.command[1].lower()

    if cmd == "on":
        if message.chat.type in [enums.ChatType.PRIVATE, enums.ChatType.BOT]:
            return await message.reply("<blockquote>{em.gagal}<b>Please enable in group.</b></blockquote>")
        if message.chat.id in await dB.get_list_from_var(client.me.id, "CHATBOT"):
            return await message.reply(f"<blockquote>{em.sukses}**Chat already in database.**</blockquote>")
        await dB.add_to_var(client.me.id, "CHATBOT", message.chat.id)
        return await message.reply(f"<blockquote>{em.sukses}<b> Chatbot turned on in this group.</b></blockquote>")

    elif cmd == "off":
        if len(message.command) < 3:
            if message.chat.type in [enums.ChatType.PRIVATE, enums.ChatType.BOT]:
                return await message.reply("<blockquote>{em.gagal}<b>Please enable in group.</b></blockquote>")
            chat_id = message.chat.id
            if chat_id not in await dB.get_list_from_var(client.me.id, "CHATBOT"):
                return await message.reply(f"<blockquote>{em.gagal}**`{chat_id}` is not found!**</blockquote>")
            await dB.remove_from_var(client.me.id, "CHATBOT", chat_id)
            name = (await client.get_chat(chat_id)).title
            return await message.reply(f"<blockquote>{em.sukses}<b>Turned off chatbot for chat: {name}</b></blockquote>")
        else:
            if message.command[2] == "all":
                for cid in await dB.get_list_from_var(client.me.id, "CHATBOT"):
                    await dB.remove_from_var(client.me.id, "CHATBOT", cid)
                return await message.reply(f"<blockquote>{em.sukses}<b>All chatbot group lists cleared.</b></blockquote>")
            else:
                try:
                    chat_id = int(message.command[2])
                except ValueError:
                    return await message.reply(
                        f"<blockquote>{em.gagal}**Invalid chat ID `{message.command[2]}`.**</blockquote>"
                    )
                if chat_id not in await dB.get_list_from_var(client.me.id, "CHATBOT"):
                    return await message.reply(f"<blockquote>{em.gagal}`{chat_id}` **Not found!**</blockquote>")
                await dB.remove_from_var(client.me.id, "CHATBOT", chat_id)
                name = (await client.get_chat(chat_id)).title
                return await message.reply(
                    f"<blockquote>{em.sukses}<b>Turned off chatbot for chat: {name}</b></blockquote>"
                )

    elif cmd == "status":
        chats = await dB.get_list_from_var(client.me.id, "CHATBOT")
        if not chats:
            return await message.reply(f"<blockquote>{em.sukses}<b>No active groups using chatbot.</b></blockquote>")
        msg = ""
        for i, chat_id in enumerate(chats, 1):
            try:
                chat = await client.get_chat(chat_id)
                msg += f"<b>{i}. {chat.title} | `{chat.id}`</b>\n"
            except Exception:
                continue
        return await message.reply(msg or f"<blockquote>{em.sukses}<b>All active groups inaccessible.</b></blockquote>")

    elif cmd == "role":
        if not message.reply_to_message:
            return await message.reply(
                f"<blockquote>{em.gagal}<b>Usage: reply to a message → `{message.text.split()[0]} role`</b></blockquote>"
            )
        role = message.reply_to_message.text or message.reply_to_message.caption
        await dB.set_var(client.me.id, "ROLE_CHATBOT", role)
        return await message.reply(f"<blockquote>{em.sukses}<b>Role set to:</b> <code>{role}</code></blockquote>")

    elif cmd == "ignore":
        reply = message.reply_to_message
        try:
            target = reply.from_user.id if reply else message.text.split()[2]
        except (AttributeError, IndexError):
            return await message.reply(
                f"<blockquote>{em.gagal}<b>You need to specify a user (either by reply or username/ID)!</b></blockquote>"
            )
        try:
            user = await client.get_users(target)
        except (
            errors.PeerIdInvalid,
            KeyError,
            errors.UsernameInvalid,
            errors.UsernameNotOccupied,
        ):
            return await message.reply(f"<blockquote>{em.gagal}<b>You need meet before interact!!</b></blockquote>")
        user_id = user.id
        if user_id in await dB.get_list_from_var(client.me.id, "CHATBOT_IGNORE"):
            return await message.reply(f"<blockquote>{em.sukses}**User already ignored chatbot.**</blockquote>")
        await dB.add_to_var(client.me.id, "CHATBOT_IGNORE", user_id)
        return await message.reply(
            f"<blockquote>{em.sukses}<b>Chatbot will now ignore {user_id} in this group.</b></blockquote>"
        )

    elif cmd == "reignore":
        reply = message.reply_to_message
        try:
            target = reply.from_user.id if reply else message.text.split()[2]
        except (AttributeError, IndexError):
            return await message.reply(
                f"<blockquote>{em.gagal}<b>You need to specify a user (either by reply or username/ID)!</b></blockquote>"
            )
        try:
            user = await client.get_users(target)
        except (
            errors.PeerIdInvalid,
            KeyError,
            errors.UsernameInvalid,
            errors.UsernameNotOccupied,
        ):
            return await message.reply(f"<blockquote>{em.gagal}<b>You need meet before interact!!</b></blockquote>")
        user_id = user.id
        if user_id not in await dB.get_list_from_var(client.me.id, "CHATBOT_IGNORE"):
            return await message.reply(f"<blockquote>{em.sukses}**User not found in database.**</blockquote>")

        await dB.remove_from_var(client.me.id, "CHATBOT_IGNORE_ADMIN", user_id)
        return await message.reply(
            f"<blockquote>{em.sukses}<b>Chatbot will now respond {user_id} again in this group.</b></blockquote>"
        )

    elif cmd == "admin":
        if len(message.command) < 3:
            return await message.reply(f"<blockquote>{em.gagal}**Please give query on or off.**</blockquote>")
        query = message.text.split()[2]
        if query.lower() == "on":
            if await dB.get_var(client.me.id, "CHATBOT_ADMIN"):
                await dB.remove_var(client.me.id, "CHATBOT_ADMIN")
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot will respond message from admins now.**</blockquote>"
                )
            else:
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot respond from admins already enable.**</blockquote>"
                )
        elif query.lower() == "off":
            if not await dB.get_var(client.me.id, "CHATBOT_ADMIN"):
                await dB.set_var(client.me.id, "CHATBOT_ADMIN", True)
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot will pass message from admins now.**</blockquote>"
                )
            else:
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot respond from admins already disable.**</blockquote>"
                )
        else:
            return await message.reply(f"<blockquote>{em.gagal}**Please give query on or off.**</blockquote>")

    elif cmd == "reply":
        if len(message.command) < 3:
            return await message.reply(f"<blockquote>{em.gagal}**Please give query on or off.**</blockquote>")
        query = message.text.split()[2]
        if query.lower() == "on":
            if not await dB.get_var(client.me.id, "CHATBOT_REPLY"):
                await dB.set_var(client.me.id, "CHATBOT_REPLY", True)
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot will respond all chats if someone reply your messages.**</blockquote>"
                )
            else:
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot reply user for all chats already enable.**</blockquote>"
                )
        elif query.lower() == "off":
            if await dB.get_var(client.me.id, "CHATBOT_REPLY"):
                await dB.remove_var(client.me.id, "CHATBOT_REPLY")
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot reply user for all chats disable.**</blockquote>"
                )
            else:
                return await message.reply(
                    f"<blockquote>{em.sukses}**Chatbot reply user for all chats already disable.**</blockquote>"
                )
        else:
            return await message.reply(f"<blockquote>{em.gagal}**Please give query on or off.**</blockquote>")

    elif cmd == "auto":
        if len(message.command) < 3:
            return await message.reply(f"<blockquote>{em.gagal}Usage: /chatbot auto on | off | status [chat_id]</blockquote>")

        query = message.text.split()[2].lower()

        # default target chat_id = current chat
        target_chat = message.chat.id  

        # kalau ada argumen tambahan, anggap itu chat_id manual
        if len(message.command) >= 4:
            try:
                target_chat = int(message.command[3])
            except ValueError:
                return await message.reply(f"Invalid chat ID `{message.command[3]}`.")

        if query == "on":
            if target_chat in await dB.get_list_from_var(client.me.id, "CHATBOT_AUTO"):
                return await message.reply(f"<blockquote>{em.sukses}Auto chatbot sudah aktif di chat `{target_chat}`.</blockquote>")
            await dB.add_to_var(client.me.id, "CHATBOT_AUTO", target_chat)

            try:
                chat_name = (await client.get_chat(target_chat)).title
            except Exception:
                chat_name = str(target_chat)

            return await message.reply(f"<blockquote>{em.sukses}Auto chatbot aktif di **{chat_name}** (`{target_chat}`).</blockquote>")

        elif query == "off":
            if target_chat not in await dB.get_list_from_var(client.me.id, "CHATBOT_AUTO"):
                return await message.reply(f"<blockquote>{em.sukses}Auto chatbot tidak aktif di chat `{target_chat}`.</blockquote>")
            await dB.remove_from_var(client.me.id, "CHATBOT_AUTO", target_chat)

            try:
                chat_name = (await client.get_chat(target_chat)).title
            except Exception:
                chat_name = str(target_chat)

            return await message.reply(f"<blockquote>{em.sukses}Auto chatbot dimatikan di **{chat_name}** (`{target_chat}`).</blockquote>")

        elif query == "status":
            chats = await dB.get_list_from_var(client.me.id, "CHATBOT_AUTO")
            if not chats:
                return await message.reply("<blockquote> {em.sukses}**Tidak ada grup yang aktif auto chatbot.**</blockquote>")

            msg = "**Daftar Auto Chatbot Aktif:**\n\n"
            for i, cid in enumerate(chats, 1):
                try:
                    chat = await client.get_chat(cid)
                    msg += f"{i}. **{chat.title}** (`{cid}`)\n"
                except Exception:
                    msg += f"{i}. (Unknown Chat) `{cid}`\n"
            return await message.reply(msg)

        else:
            return await message.reply(f"<blockquote>{em.sukses}Usage: /chatbot auto on | off | status [chat_id]</blockquote>")

    else:
        return await message.reply(
            f"<blockquote>{em.gagal}<b>Usage: `{message.text.split()[0]} on | off | status | role | ignoreadmin | reignoreadmin | auto`</b></blockquote>"
        )


async def auto_reply_trigger(client, message):
    ...
    # (tidak diubah)


async def chatbot_trigger(client, message):
    ...
    # (tidak diubah)


async def ChatbotTask():
    logger.info("✅ Chatbot tasks started")
    for user_id in session.get_list():
        client = session.get_session(user_id)  # ← perbaikan
        if not client:
            continue
        if client.me.id in userbot_ids:
            continue
        try:
            userbot_ids.add(client.me.id)  # ← perbaikan
            asyncio.create_task(chatbot_task_loop(client))  # ← perbaikan
        except Exception as e:
            if client.me.id in userbot_ids:
                userbot_ids.remove(client.me.id)  # ← perbaikan


async def chatbot_auto_trigger(client, message):
    if not message.from_user or not message.chat:
        return

    # hanya jalan kalau grup ini ada di list AUTO
    if message.chat.id not in await dB.get_list_from_var(client.me.id, "CHATBOT_AUTO"):
        return

    if message.from_user.id in await dB.get_list_from_var(client.me.id, "CHATBOT_IGNORE"):
        return

    if await dB.get_var(client.me.id, "CHATBOT_ADMIN"):
        if message.from_user.id in await client.admin_list(message):
            return

    text = message.text or message.caption
    if text:
        for word in config.BLACKLIST_KATA:
            if word in text:
                return
        if url_mmk(text):
            return

        await client.send_chat_action(message.chat.id, enums.ChatAction.TYPING)
        response = await gen_text(client, message)

        if response:
            try:
                await message.reply(response)
                await add_auto_text(response)
            except errors.FloodWait as e:
                await asyncio.sleep(e.value)
                await message.reply(response)
                await add_auto_text(response)
        else:
            fallback = await get_random_text()
            if fallback:
                await message.reply(random.choice(fallback))

        return await client.send_chat_action(message.chat.id, enums.ChatAction.CANCEL)