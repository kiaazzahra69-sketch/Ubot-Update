import asyncio
from datetime import datetime, timedelta

from pyrogram import raw
from pyrogram.errors import (ChannelInvalid, FloodWait, InputUserDeactivated,
                             PeerIdInvalid, UserIsBlocked, UsernameNotOccupied)
from pyrogram.helpers import kb
from pytz import timezone

from clients import bot, session
from config import (AKSES_DEPLOY, BOT_ID, IS_JASA_PRIVATE, KYNAN, LOG_SELLER,
                    SUDO_OWNERS)
from database import dB

from .addubot_command import setExpiredUser


async def sewa_expired(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in KYNAN:
        return
    if len(message.command) < 2:
        return await message.reply("<blockquote>>**Gunakan perintah: /sewa total-hari**</blockquote>")
    get_day = int(message.command[1])
    now = datetime.now(timezone("Asia/Jakarta"))
    expire_date = now + timedelta(days=int(get_day))
    await dB.set_expired_date(client.me.id, expire_date)
    return await message.reply(
        f"<blockquote>{client.me.id} telah diaktifkan selama {get_day} hari.</blockquote>"
    )


async def set_plan(client, message):
    user = message.from_user.id
    reseller = await dB.get_list_from_var(BOT_ID, "SELLER")
    if user not in reseller:
        return await message.reply("<blockquote><b>Kamu bukan reseller!!</b></blockquote>")
    user_id, plan = await client.extract_user_and_reason(message)
    if not user_id:
        return await message.reply(
            f"<blockquote>{message.text.split()[0]} user_id/username plan\nContoh: {message.text.split()[0]} @username is_pro</blockquote>"
        )
    try:
        get_id = (await client.get_users(user_id)).id
    except Exception as error:
        return await message.reply(str(error))
    bef_plan = await dB.get_var(user_id, "plan")
    if not plan:
        return await message.reply(
            "<blockquote>Silahkan berikan plan `lite`, `basic` atau `is_pro`.</blockquote>"
        )
    if plan not in ["lite", "basic", "is_pro"]:
        return await message.reply(
            "<blockquote>Silahkan berikan plan `lite`, `basic` atau `is_pro`.</blockquote>"
        )
    await dB.set_var(user_id, "plan", plan)
    return await message.reply(
        f"<blockquote>Pengguna {get_id} telah ditetapkan plan dari: `{bef_plan}` menjadi `{plan}` .</blockquote>"
    )


async def add_prem_user(client, message):
    cmd_plan = message.command[0]
    if cmd_plan == "pro":
        user_plan = "is_pro"
    elif cmd_plan == "addprem":
        if not IS_JASA_PRIVATE:
            return await message.reply("<blockquote><b>This command only for Ubot Private</b></blockquote>")
        user_plan = "is_pro"
    else:
        user_plan = cmd_plan
    user = message.from_user
    reseller = await dB.get_list_from_var(BOT_ID, "SELLER")
    if user.id not in reseller:
        return await message.reply("<blockquote><b>Kamu bukan reseller!!</b></blockquote>")
    user_id, get_bulan = await client.extract_user_and_reason(message)
    if not user_id:
        return await message.reply(
            f"<blockquote><b>{message.text.split()[0]} [user_id/username - bulan]</b></blockquote>"
        )
    try:
        get_id = (await client.get_users(user_id)).id
    except Exception as error:
        return await message.reply(str(error))
    if not get_bulan:
        get_bulan = 1
    premium = AKSES_DEPLOY
    if get_id in premium:
        return await message.reply(
            f"<blockquote>Pengguna denga ID : `{get_id}` sudah memiliki akses !</blockquote>"
        )
    AKSES_DEPLOY.append(get_id)
    if not await dB.get_expired_date(get_id):
        await setExpiredUser(get_id)
    await message.reply(
        f"<blockquote>✅  <b>Akses {user_plan} diberikan kepada {get_id}!! Silahkan pergi ke @{bot.me.username}</blockquote>"
    )
    target1 = f"<a href=tg://user?id={message.from_user.id}>{message.from_user.first_name} {message.from_user.last_name or ''}</a>"
    try:
        target = await bot.get_users(user_id)
        target2 = f"<a href=tg://user?id={target.id}>{target.first_name} {target.last_name or ''}</a>"
    except Exception:
        target2 = get_id
    await bot.send_message(
        LOG_SELLER,
        f"<b>User: {target1} gives access to: {target2}, plan {cmd_plan}</b>",
    )
    await dB.set_var(get_id, "plan", user_plan)
    try:
        return await bot.send_message(
            get_id,
            f"<blockquote>Selamat ! Akun anda sudah memiliki akses untuk pembuatan Userbot</blockquote>",
            reply_markup=kb(
                [["✅ Lanjutkan Buat Userbot"]],
                resize_keyboard=True,
                one_time_keyboard=True,
            ),
        )
    except Exception:
        pass


async def un_prem_user(client, message):
    user = message.from_user
    reseller = await dB.get_list_from_var(BOT_ID, "SELLER")
    if user.id not in reseller:
        return await message.reply("<blockquote><b>Kamu bukan reseller!!</b></blockquote>")
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply("<blockquote>Balas pesan pengguna atau berikan user_id/username</blockquote>")
    try:
        user = await client.get_users(user_id)
    except Exception as error:
        await message.reply(str(error))
    delpremium = AKSES_DEPLOY
    if user.id not in delpremium:
        return await message.reply("<blockquote>Tidak ditemukan</blockquote>")
    AKSES_DEPLOY.remove(user.id)
    await dB.rem_expired_date(user.id)
    await dB.remove_var(user.id, "plan")
    return await message.reply(f"<blockquote> ✅ {user.mention} berhasil dihapus</blockquote>")


async def add_seller(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    user = None
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply("<blockquote>Balas pesan pengguna atau berikan user_id/username</blockquote>")
    try:
        user = await client.get_users(user_id)
    except Exception as error:
        await message.reply(str(error))
    seles = await dB.get_list_from_var(BOT_ID, "SELLER")
    if user.id in seles:
        return await message.reply("<blockquote>Sudah menjadi reseller.</blockquote>")

    await dB.add_to_var(BOT_ID, "SELLER", user.id)
    return await message.reply(f"<blockquote>✅ {user.mention} telah menjadi reseller</blockquote>")


async def un_seller(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    user = None
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply("<blockquote>Balas pesan pengguna atau berikan user_id/username</blockquote>")
    try:
        user = await client.get_users(user_id)
    except Exception as error:
        await message.reply(str(error))
    seles = await dB.get_list_from_var(BOT_ID, "SELLER")
    if user.id not in seles:
        return await message.reply("<blockquote>Tidak ditemukan</blockquote>")
    await dB.remove_from_var(BOT_ID, "SELLER", user.id)
    return await message.reply(f"<blockquote>{user.mention} berhasil dihapus</blockquote>")


async def send_broadcast(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    users = await dB.get_list_from_var(client.me.id, "BROADCAST")
    if not message.reply_to_message:
        return await message.reply("<blockquote><b>Silahkan balas ke pesan!</b></blockquote>")
    gagal = 0
    sukses = 0
    x = message.reply_to_message.id
    y = message.chat.id
    for i in users:
        try:
            (
                await client.forward_messages(i, y, x)
                if message.reply_to_message
                else await client.send_message(i, y, x)
            )
            sukses += 1
        except FloodWait as e:
            await asyncio.sleep(e.value)
            (
                await client.forward_messages(i, y, x)
                if message.reply_to_message
                else await client.send_message(i, y, x)
            )
            sukses += 1
        except UserIsBlocked:
            await dB.remove_from_var(BOT_ID, "BROADCAST", i)
            gagal += 1
            continue
        except PeerIdInvalid:
            await dB.remove_from_var(BOT_ID, "BROADCAST", i)
            gagal += 1
            continue
        except InputUserDeactivated:
            await dB.remove_from_var(BOT_ID, "BROADCAST", i)
            gagal += 1
            continue
    return await message.reply(
        f"<blockquote><b>Berhasil mengirim pesan ke `{sukses}` pengguna, gagal ke `{gagal}` pengguna, dari `{len(users)}` pengguna.</b></blockquote>",
    )


async def mass_report(client, message):
    devs = message.from_user if message.from_user else message.sender_chat
    if devs.id not in SUDO_OWNERS:
        return
    if len(message.command) < 2:
        await message.reply(
            "<blockquote>Please provide a channel username.\nUsage: `massreport [user|channel] username`</blockquote>"
        )
        return
    command, uname = client.extract_type_and_msg(message)
    if command == "channel":
        report_text = (
            "This channel spreads fake news, misleads people, thereby inciting aggression "
            "and calling for war between nations. It contains posts with violent threats to the life "
            "and health of Ukrainian citizens. Under international law, this is regarded as terrorism. "
            "Therefore we ask You to block it as soon as possible!"
        )
        status_msg = await message.reply(f"<blockquote>⏳ Reporting {uname}...</blockquote>")
        try:
            for user_id in session.get_list():
                user = session.get_session(user_id)
                if user:
                    try:
                        peer = await user.resolve_peer(uname)
                    except UsernameNotOccupied:
                        await message.reply(f"<blockquote>❌ Username {uname} does not exist.</blockquote>")
                        return
                    except ChannelInvalid:
                        await message.reply(
                            f"<blockquote>❌ Channel @{uname} is invalid or not accessible.</blockquote>"
                        )
                        return
                    except PeerIdInvalid:
                        await message.reply(f"<blockquote>❌ Cannot find entity {uname}.</blockquote>")
                        return
                    await user.invoke(
                        raw.functions.account.ReportPeer(
                            peer=peer,
                            reason=raw.types.InputReportReasonOther(),
                            message=report_text,
                        )
                    )

            return await status_msg.edit(f"<blockquote>✅ {uname} has been reported successfully.</blockquote>")

        except Exception as e:
            import traceback

            error_traceback = traceback.format_exc()
            return await status_msg.reply(
                f"<blockquote>❌ Error occurred while reporting:\n`{error_traceback}`</blockquote>"
            )
    elif command == "user":
        try:
            status_msg = await message.reply(
                f"<blockquote>⏳ Processing report for user {uname}...</blockquote>"
            )
            report_text = (
                "This user spreads fake news, misleads people, thereby inciting aggression "
                "and calling for war between nations. The account contains violent threats "
                "and promotes harmful content. Under platform guidelines, this account "
                "should be suspended. Please review and take appropriate action."
            )
            for user_id in session.get_list():
                user = session.get_session(user_id)
                if user:
                    try:
                        peer = await user.resolve_peer(uname)
                    except UsernameNotOccupied:
                        await status_msg.edit(f"<blockquote>❌ Username {uname} does not exist.</blockquote>")
                        return
                    except PeerIdInvalid:
                        await status_msg.edit(f"<blockquote>❌ Cannot find user {uname}.</blockquote>")
                        return
                    await user.invoke(
                        raw.functions.account.ReportPeer(
                            peer=peer,
                            reason=raw.types.InputReportReasonOther(),
                            message=report_text,
                        )
                    )
            return await status_msg.edit(
                f"<blockquote>✅ User @{uname} has been reported successfully.</blockquote>"
            )

        except Exception as e:
            import traceback

            error_traceback = traceback.format_exc()
            return await status_msg.edit(
                f"<blockquote>❌ Error occurred while reporting user:\n`{error_traceback}`</blockquote>"
            )


async def get_seles_user(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    text = ""
    count = 0
    seles = await dB.get_list_from_var(BOT_ID, "SELLER")
    for user_id in seles:
        try:
            user = await client.get_users(user_id)
            count += 1
            userlist = f"• {count}: <a href=tg://user?id={user.id}>{user.first_name} {user.last_name or ''}</a> > <code>{user.id}</code>"
        except Exception:
            continue
        text += f"<blockquote expandable>{userlist}\n</blockquote>"
    if not text:
        return await message.reply_text("<blockquote>Tidak ada pengguna yang ditemukan</blockquote>")
    else:
        return await message.reply_text(text)


async def addexpired_user(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    user_id, get_day = await client.extract_user_and_reason(message)
    if not user_id:
        return await message.reply(f"<blockquote>{message.text.split()[0]} user_id/username - hari</blockquote>")
    try:
        get_id = (await client.get_users(user_id)).id
    except Exception as error:
        return await message.reply(str(error))
    if not get_day:
        get_day = 30
    now = datetime.now(timezone("Asia/Jakarta"))
    expire_date = now + timedelta(days=int(get_day))
    await dB.set_expired_date(user_id, expire_date)
    return await message.reply(f"<blockquote>{get_id} telah diaktifkan selama {get_day} hari.</blockquote>")


async def cek_expired(client, message):
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply("<blockquote>Pengguna tidak ditemukan</blockquote>")
    expired_date = await dB.get_expired_date(user_id)
    if not expired_date:
        return await message.reply(f"<blockquote>{user_id} belum diaktifkan.</blockquote>")
    expir = expired_date.astimezone(timezone("Asia/Jakarta")).strftime("%Y-%m-%d %H:%M")
    return await message.reply(f"<blockquote>{user_id} aktif hingga {expir}.</blockquote>")


async def unexpired(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    user = None
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply("<blockquote>User tidak ditemukan</blockquote>")
    try:
        user = await client.get_users(user_id)
    except Exception as error:
        return await message.reply(str(error))
    await dB.rem_expired_date(user.id)
    return await message.reply(f"<blockquote>✅ {user.id} expired telah dihapus</blockquote>")


async def get_prem_user(client, message):
    user = message.from_user if message.from_user else message.sender_chat
    if user.id not in SUDO_OWNERS:
        return
    text = ""
    count = 0
    for user_id in AKSES_DEPLOY:
        try:
            user = await client.get_users(user_id)
            count += 1
            userlist = f"• {count}: <a href=tg://user?id={user.id}>{user.first_name} {user.last_name or ''}</a> > <code>{user.id}</code>"
        except Exception:
            continue
        text += f"<blockquote>{userlist}\n</blockquote>"
    if not text:
        return await message.reply_text("<blockquote>Tidak ada pengguna yang ditemukan</blockquote>")
    else:
        return await message.reply_text(text)


async def seller_cmd(client, message):
    reseller = await dB.get_list_from_var(BOT_ID, "SELLER")
    if not reseller:
        return await message.reply("<blockquote><b>Kamu belum memiliki reseller!!</b></blockquote>")
    msg = ""
    for count, usr in enumerate(reseller, 1):
        try:
            data = await dB.get_var(usr, "penjualan") or 0
            mention = (await bot.get_users(int(usr))).mention
        except Exception:
            continue
        msg += f"<blockquote expandable>{count}.<b>{mention} | penjualan bulan ini</b> {data}\n</blockquote>"
    return await message.reply(msg)
