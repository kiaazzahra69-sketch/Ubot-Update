from database import dB
from helpers import Emoji, animate_proses

from .autobc_command import extract_type_and_text


async def autoread_cmd(client, message):
    em = Emoji(client)
    await em.get()

    proses = await animate_proses(message, em.proses)
    if len(message.command) < 2:
        await proses.edit(f"<blockquote>{em.gagal}**Please type see help for module.**</blockquote>")
        return
    query, value = extract_type_and_text(message)
    if query.lower() == "time":
        if value.isnumeric():
            lmt = int(value)
            await dB.set_var(client.me.id, "TIME_READ", lmt)
            await proses.edit(f"<blockquote>{em.sukses}Time autoread set to: `{lmt}`</blockquote>")
            return
        else:
            await proses.edit(f"<blockquote>{em.gagal}Please give me seconds time!!</blockquote>")
            return
    elif query.lower() == "group":
        if value.lower() == "on":
            await dB.set_var(client.me.id, "READ_GC", True)
            await proses.edit(f"<blockquote>{em.sukses}**Successfully turned on group autoread.**</blockquote>")
            return
        elif value.lower() == "off":
            await dB.remove_var(client.me.id, "READ_GC")
            await proses.edit(
                f"<blockquote>{em.sukses}**Autoread {query} was successfully disabled.**</blockquote>"
            )
            return
        else:
            return await proses.edit(f"<blockquote>{em.gagal}**Please use value on or off!!**</blockquote>")
    elif query.lower() == "private":
        if value.lower() == "on":
            await dB.set_var(client.me.id, "READ_US", True)
            await proses.edit(f"<blockquote>{em.sukses}**Successfully turned on user autoread.**</blockquote>")
            return
        elif value.lower() == "off":
            await dB.remove_var(client.me.id, "READ_US")
            await proses.edit(
                f"<blockquote>{em.sukses}**Autoread {query} was successfully disabled.**</blockquote>"
            )
            return
        else:
            return await proses.edit(f"<blockquote>{em.gagal}**Please use value on or off!!**</blockquote>")
    elif query.lower() == "bot":
        if value.lower() == "on":
            await dB.set_var(client.me.id, "READ_BOT", True)
            await proses.edit(f"<blockquote>{em.sukses}**Successfully turned on autoread bot.**</blockquote>")
            return
        elif value.lower() == "off":
            await dB.remove_var(client.me.id, "READ_BOT")
            await proses.edit(
                f"<blockquote>{em.sukses}**Autoread {query} was successfully disabled.**</blockquote>"
            )
            return
        else:
            return await proses.edit(f"<blockquote>{em.gagal}**Please use value on or off!!**</blockquote>")
    elif query.lower() == "channel":
        if value.lower() == "on":
            await dB.set_var(client.me.id, "READ_CH", True)
            await proses.edit(
                f"<blockquote>{em.sukses}**Successfully turned on autoread channel.**</blockquote>"
            )
            return
        elif value.lower() == "off":
            await dB.remove_var(client.me.id, "READ_CH")
            await proses.edit(
                f"<blockquote>{em.sukses}**Autoread {query} was successfully disabled.**</blockquote>"
            )
            return

        else:
            return await proses.edit(f"<blockquote>{em.gagal}**Please use value on or off!!**</blockquote>")
    elif query.lower() == "tag":
        if value.lower() == "on":
            await dB.set_var(client.me.id, "READ_MENTION", True)
            await proses.edit(f"<blockquote>{em.sukses}**Successfully turned on autoread mention.</blockquote>")
            return
        elif value.lower() == "off":
            await dB.remove_var(client.me.id, "READ_MENTION")
            await proses.edit(
                f"<blockquote>{em.sukses}**Autoread {query} was successfully disabled.**</blockquote>"
            )
            return
        else:
            return await proses.edit(f"<blockquote>{em.gagal}**Please use value on or off!!**</blockquote>")
    elif query.lower() == "all":
        if value.lower() == "on":
            await dB.set_var(client.me.id, "READ_ALL", True)
            await proses.edit(f"<blockquote>{em.sukses}**Successfully turned on autoread all.**</blockquote>")
            return
        elif value.lower() == "off":
            await dB.remove_var(client.me.id, "READ_ALL")
            await proses.edit(
                f"<blockquote>{em.sukses}**Autoread {query} was successfully disabled.**</blockquote>"
            )
            return
        else:
            return await proses.edit(f"<blockquote>{em.gagal}**Please use value on or off!!**</blockquote>")
    elif query.lower() == "status":
        time_read = await dB.get_var(client.me.id, "TIME_READ") or 3600
        read_gc = (
            f"<blockquote>{em.sukses}**On**</blockquote>"
            if await dB.get_var(client.me.id, "READ_GC")
            else f"<blockquote>{em.gagal}**Off**</blockquote>"
        )
        read_us = (
            f"<blockquote>{em.sukses}**On**</blockquote>"
            if await dB.get_var(client.me.id, "READ_US")
            else f"<blockquote>{em.gagal}**Off**</blockquote>"
        )
        read_bot = (
            f"<blockquote>{em.sukses}**On**</blockquote>"
            if await dB.get_var(client.me.id, "READ_BOT")
            else f"<blockquote>{em.gagal}**Off**</blockquote>"
        )
        read_ch = (
            f"<blockquote>{em.sukses}**On**</blockquote>"
            if await dB.get_var(client.me.id, "READ_CH")
            else f"<blockquote>{em.gagal}**Off**</blockquote>"
        )
        read_tag = (
            f"<blockquote>{em.sukses}**On**</blockquote>"
            if await dB.get_var(client.me.id, "READ_MENTION")
            else f"<blockquote>{em.gagal}**Off**</blockquote>"
        )
        read_all = (
            f"<blockquote>{em.sukses}**On**</blockquote>"
            if await dB.get_var(client.me.id, "READ_ALL")
            else f"<blockquote>{em.gagal}**Off**</blockquote>"
        )

        status_text = (
            f"<blockquote expandable>{em.proses}**Autoread Status**\n\n"
            f"{em.uptime}**Time Read: `{time_read}` seconds**\n"
            f"{em.profil}**Group:** {read_gc}\n"
            f"{em.msg}**Private:** {read_us}\n"
            f"{em.robot}**Bot:** {read_bot}\n"
            f"{em.klip}**Channel:** {read_ch}\n"
            f"{em.owner}**Mention:** {read_tag}\n"
            f"{em.speed}**All:** {read_all}</blockquote>"
        )
        await proses.edit(status_text)
        return

    else:
        await proses.edit(f"<blockquote>{em.gagal}**Please enter the query correctly!!**</blockquote>")
        return
