from datetime import datetime

from database import dB
from helpers import AUTOFW_STATUS, Emoji, Tools, animate_proses


def extract_type_and_text(message):
    args = message.text.split(None, 2)
    if len(args) < 2:
        return None, None

    type = args[1]
    msg = (
        message.reply_to_message.text
        if message.reply_to_message
        else args[2] if len(args) > 2 else None
    )
    return type, msg


async def autofw_cmd(client, message):
    em = Emoji(client)
    await em.get()

    msg = await animate_proses(message, em.proses)
    type, value = extract_type_and_text(message)
    status_autofw = await dB.get_var(client.me.id, "AUTOFW_GCAST_TEXT")
    if type == "on":
        if not status_autofw:
            return await msg.edit(
                f"<blockquote>{em.gagal}**Please add link before setting it on!!**\n**Example:** `{message.text.split()[0]} add https://t.me/storepler/1884`</blockquote>"
            )
        if await dB.get_var(client.me.id, "AUTOFW"):
            return await msg.edit(f"<blockquote>{em.gagal}<b>Auto forward already turned on.</b></blockquote>")
        else:
            await dB.set_var(client.me.id, "AUTOFW", True)
            return await msg.edit(f"<blockquote>{em.sukses}<b>Auto forward turned on.</b></blockquote>")
    elif type == "off":
        if await dB.get_var(client.me.id, "AUTOFW") and client.me.id in AUTOFW_STATUS:
            AUTOFW_STATUS.remove(client.me.id)
            await dB.remove_var(client.me.id, "AUTOFW")
            return await msg.edit(f"<blockquote>{em.gagal}<b>Auto forward has been stopped.</b></blockquote>")
        else:
            return await msg.edit(f"<blockquote>{em.sukses}<b>Auto forward already off.</b></blockquote>")
    elif type == "add":
        try:
            target, messageids = Tools.get_link(value)
        except TypeError:
            return await msg.edit(
                f"<blockquote>{em.gagal}**Please give me valid link.\nExample: `{message.text.split()[0]} add https://t.me/storepler/1884`**</blockquote>",
                disable_web_page_preview=True,
            )
        args = await client.get_messages(target, messageids)
        if args.empty == True:
            return await msg.edit(
                f"<blockquote>{em.gagal}**Please give me valid link.\nExample: `{message.text.split()[0]} add https://t.me/storepler/1884`**</blockquote>",
                disable_web_page_preview=True,
            )
        await dB.set_var(client.me.id, "AUTOFW_GCAST_TEXT", value)
        return await msg.edit(
            f"<blockquote>{em.sukses}<b>Saved {value} for AutoForward Gcast message.</b></blockquote>",
            disable_web_page_preview=True,
        )
    elif type == "delay":
        await dB.set_var(client.me.id, "DELAY_AUTOFW", value)
        return await msg.edit(
            f"<blockquote>{em.sukses}<b>AutoForward Gcast delay set to: <code>{value}</code> Second.</b></blockquote>"
        )
    elif type == "del":
        try:
            await dB.remove_var(client.me.id, "AUTOFW_GCAST_TEXT")
            return await msg.edit(
                f"<blockquote>{em.sukses}<b>Succesfully deleted link from database.</b></blockquote>"
            )
        except Exception as error:
            return await msg.edit(str(error))

    elif type == "get":
        if not status_autofw:
            return await msg.edit(
                f"<blockquote>{em.gagal}<b>Your AutoForward Gcast link is empty, idiot.</b></blockquote>"
            )
        return await msg.edit(
            f"<blockquote>{em.sukses}**This is your link autoforward gcast: {status_autofw}</blockquote>",
            disable_web_page_preview=True,
        )

    elif type == "status":
        status = await dB.get_var(client.me.id, "AUTOFW")
        delay = await dB.get_var(client.me.id, "DELAY_AUTOFW") or 300
        msgs = await dB.get_var(client.me.id, "AUTOFW_GCAST_TEXT")
        rounds = await dB.get_var(client.me.id, "ROUNDSFW") or 0
        last_broadcast = await dB.get_var(client.me.id, "LAST_TIME_FW") or 0
        status_text = f"<blockquote>{em.sukses}Actived</blockquote>" if status else f"<blockquote>{em.gagal}Deactivated</blockquote>"
        last_broadcast_time = (
            f"<code>{datetime.utcfromtimestamp(last_broadcast).strftime('%Y-%m-%d %H:%M:%S')} UTC</code>"
            if last_broadcast
            else "No auto forward yet"
        )
        total_groups = await dB.get_var(client.me.id, "SUCCESFW_GROUP") or 0
        await msg.edit(
            f"""
<blockquote expandable>**__📑 Status Auto Broadcast:
👤 Status: {status_text}
🗓️ Group Count: {total_groups}
⌛ Delay: {delay}  detik 
📑 Link AutoFW: {(msgs)} Pesan
🔃 Rounds: {rounds} Kali
⏰ Last AutoFW: {last_broadcast_time}__**</blockquote>""",
            disable_web_page_preview=True,
        )
    else:
        return await msg.edit(
            f"<blockquote>{em.gagal}<b>Wrong, idiot!! At least read the  Command Help.</b></blockquote>"
        )
    return
