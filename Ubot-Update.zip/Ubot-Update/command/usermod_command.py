import asyncio
import os
import random
import re
import traceback
from datetime import datetime
from io import BytesIO
from time import time

from pyrogram import enums, raw
from pyrogram.enums import ChatMemberStatus, ChatType, StoriesPrivacyRules
from pyrogram.errors import (ChannelPrivate, FloodPremiumWait, FloodWait,
                             PeerIdInvalid, UsernameOccupied,
                             UserNotParticipant)
from pyrogram.raw import functions

from clients import session
from config import HELPABLE
from database import dB
from helpers import (Basic_Effect, Emoji, Premium_Effect, Tools,
                     animate_proses, get_time, start_time, task)
from logs import logger

RANDOM_EMOJIS = [
    "😀",
    "😂",
    "😍",
    "😎",
    "😢",
    "😡",
    "👍",
    "👎",
    "🙏",
    "👏",
    "❤️",
    "🗿",
    "😭",
    "🔥",
]


async def set_pong_message(user_id, new_message):
    await dB.set_var(user_id, "text_ping", new_message)
    return


async def set_utime_message(user_id, new_message):
    await dB.set_var(user_id, "text_uptime", new_message)
    return


async def set_owner_message(user_id, new_message):
    await dB.set_var(user_id, "text_owner", new_message)
    return


async def set_ubot_message(user_id, new_message):
    await dB.set_var(user_id, "text_ubot", new_message)
    return


async def set_gcast_message(user_id, new_message):
    await dB.set_var(user_id, "text_gcast", new_message)
    return


async def set_sukses_message(user_id, new_message):
    await dB.set_var(user_id, "text_sukses", new_message)
    return


async def set_help_message(user_id, new_message):
    await dB.set_var(user_id, "text_help", new_message)
    return


costumtext_query = {
    "ping": set_pong_message,
    "uptime": set_utime_message,
    "owner": set_owner_message,
    "ubot": set_ubot_message,
    "proses": set_gcast_message,
    "sukses": set_sukses_message,
    "help": set_help_message,
}


async def blocked_cmd(client, message):
    em = Emoji(client)
    await em.get()
    proses = await animate_proses(message, em.proses)
    if message.command[0] == "blocked":
        users = await client.invoke(
            raw.functions.contacts.GetBlocked(offset=0, limit=2000)
        )
        total = len([t.peer_id.user_id for t in users.blocked])
        return await proses.edit(f"<blockquote>{em.sukses}**Users as bloked is `{total}`.**</blockquote>")
    elif message.command[0] == "unblockall":
        sukses = 0
        users = await client.invoke(
            raw.functions.contacts.GetBlocked(offset=0, limit=2000)
        )
        total = [t.peer_id.user_id for t in users.blocked]
        for target in total:
            try:
                await client.unblock_user(target)
                sukses += 1
            except Exception:
                continue
        return await proses.edit(
            f"<blockquote>{em.gagal}**Successfully unblocked a total of `{sukses}` users out of {len(total)} users.**</blockquote>"
        )


async def settext_cmd(client, message):
    em = Emoji(client)
    await em.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await em.get_costum_text()
    pros = await animate_proses(message, em.proses)

    args = message.text.split(maxsplit=2)
    variable = args[1]
    new_message = client.new_arg(message)
    if variable in costumtext_query:
        await costumtext_query[variable](client.me.id, new_message)
        return await pros.edit(
            f"<blockquote>{em.sukses}**Successfully updated custom text: <u>{variable}</u>**</blockquote>"
        )
    else:
        return await pros.edit(
            f"<blockquote>{em.gagal}**Please given text for this query: {variable}!**</blockquote>"
        )


"""
async def mping_cmd(client, message):
    em = Emoji(client)
    await em.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await em.get_costum_text()
    start = datetime.now()
    await client.invoke(Ping(ping_id=0))
    end = datetime.now()
    upnya = await get_time((time() - start_time))
    duration = round((end - start).microseconds / 100000, 2)
    _ping = f"<blockquote><b>{em.ping}{pong_}:</b> <u>{duration}ms</u>\n<b>{em.uptime}{uptime_}:</b> <u>{upnya}</u>\n<b>{em.owner}{owner_}</b></blockquote>"
    if message._client.me.is_premium == True:
        effect_id = random.choice(Premium_Effect)
    else:
        effect_id = random.choice(Basic_Effect)
    if message.chat.type == enums.ChatType.PRIVATE:
        return await message.reply(_ping, effect_id=effect_id)
    else:
        return await message.reply(_ping)
"""


async def mping_cmd(client, message):
    em = Emoji(client)
    await em.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await em.get_costum_text()
    proses = await message.reply(f"<blockquote>{em.proses}**Ping...**</blockquote>")
    out, _ = await Tools.bash("ping -c 2 165.22.53.26")
    matches = re.findall(r"time=([\d.]+)\s?ms", out)
    ping_result = f"{matches[-1]}"
    upnya = await get_time((time() - start_time))
    plan_mode = await dB.get_var(client.me.id, "plan")
    if plan_mode in ["is_pro", "basic"]:
        _ping = (
            f"<blockquote><b>{em.ping}{pong_}:</b> {ping_result} ms\n"
            f"<b>{em.uptime}{uptime_}:</b> {upnya}\n"
            f"<b>{em.owner}{owner_}</b></blockquote>"
        )
    else:
        _ping = f"<blockquote><b>{em.ping}{pong_}:</b> {ping_result} ms\n</blockquote>"

    if message._client.me.is_premium:
        effect_id = random.choice(Premium_Effect)
    else:
        effect_id = random.choice(Basic_Effect)
    await proses.delete()
    if message.chat.type == enums.ChatType.PRIVATE:
        return await message.reply(_ping, effect_id=effect_id)
    else:
        return await message.reply(_ping)

async def add_absen(user_id, text):
    auto_text = await dB.get_var(user_id, "TEXT_ABSEN") or []
    auto_text.append(text)
    await dB.set_var(user_id, "TEXT_ABSEN", auto_text)


async def absen_cmd(client, message):
    txt = await dB.get_var(client.me.id, "TEXT_ABSEN")
    if len(message.command) == 1:
        if not txt:
            return
        try:
            psn = random.choice(txt)
            return await message.reply(psn)
        except:
            pass
    else:
        command, variable = message.command[:2]
        if variable.lower() == "text":
            for user_id in session.get_list():
                value = " ".join(message.command[2:])
                await add_absen(user_id, value)

        else:
            return


async def setprefix_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await emo.get_costum_text()
    pros = await animate_proses(message, emo.proses)
    if len(message.command) < 2:
        m = message.text.split()[0]
        return await pros.edit(
            f"<blockquote expandable>{emo.gagal}<b>Please provide the Prefix/Handler you want to use.</b>\n\n"
            f"Example:\n<code>{m}setprefix , . ? : ;</code>\n\n"
            f"Or use <code>none</code> if you want to use commands without a Prefix/Handler.</blockquote>"
        )
    ub_prefix = []
    for prefix in message.command[1:]:
        if prefix.lower() == "none":
            ub_prefix.append("")
        else:
            ub_prefix.append(prefix)
    try:
        client.set_prefix(ub_prefix)
        await dB.set_pref(client.me.id, ub_prefix)
        parsed_prefix = (
            " ".join(f"<code>{prefix}</code>" for prefix in ub_prefix if prefix)
            or "none"
        )
        return await pros.edit(
            f"<blockquote>{emo.sukses}<b>Successfully set the Prefix to: {parsed_prefix}</b></blockquote>"
        )
    except Exception as error:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>ERROR: <code>{error}</code></b></blockquote>")


async def setonline_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pref = client.get_prefix(client.me.id)
    x = next(iter(pref))
    rep = message.reply_to_message
    if len(message.command) == 1 and not rep:
        return await message.reply(
            f"<blockquote>{emo.gagal}<b>Use the command like this:</b>\n<code>{x}setonline</code> on/off.</blockquote>"
        )
    pros = await animate_proses(message, emo.proses)
    handle = message.text.split(None, 1)[1]
    try:
        if handle.lower() == "off":
            await client.invoke(functions.account.UpdateStatus(offline=False))
            return await pros.edit(
                f"<blockquote>{emo.sukses}<b>Successfully changed online status to: <code>{handle}</code></b></blockquote>"
            )
        elif handle.lower() == "on":
            await client.invoke(functions.account.UpdateStatus(offline=True))
            return await pros.edit(
                f"<blockquote>{emo.sukses}<b>Successfully changed online status to: <code>{handle}</code></b></blockquote>"
            )
        else:
            return await pros.edit(
                f"<blockquote>{emo.gagal}<b>Use the command like this:</b>\n<code>{x}setonline</code> on/off.</blockquote>"
            )
    except Exception as e:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b>\n<code>{e}</code></blockquote>")


async def unblock_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply(
            f"<blockquote>{emo.gagal}<b>Provide username/user_id/reply to user's message.</b></blockquote>"
        )
    pros = await animate_proses(message, emo.proses)
    try:
        user = await client.get_users(user_id)
    except PeerIdInvalid:
        return await pros.edit(
            f"<blockquote>{emo.gagal}<b>I have never interacted with <code>{user_id}</code></b></blockquote>"
        )
    except Exception as e:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b>\n<code>{str(e)}</code></blockquote>")
    if user.id == client.me.id:
        return await pros.edit(f"{emo.sukses}<b>Ok!</b>")
    await client.unblock_user(user.id)
    return await pros.edit(f"<blockquote>{emo.sukses}<b>Successfully unblocked {user.mention}.</b></blockquote>")


async def block_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    user_id = await client.extract_user(message)
    if not user_id:
        return await message.reply(
            f"<blockquote>{emo.gagal}<b>Provide username/user_id or reply to user's message.</b></blockquote>"
        )
    pros = await animate_proses(message, emo.proses)
    try:
        user = await client.get_users(user_id)
    except PeerIdInvalid:
        return await pros.edit(
            f"<blockquote>{emo.gagal}<b>I have never interacted with <code>{user_id}</code></b></blockquote>"
        )
    except Exception as e:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b>\n<code>{str(e)}</code></blockquote>")
    if user.id == client.me.id:
        return await pros.edit(f"{emo.sukses}<b>Ok!</b>")
    await client.block_user(user_id)
    return await pros.edit(f"<blockquote>{emo.sukses}<b>Successfully blocked {user.mention}.</b></blockquote>")


async def setname_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pros = await animate_proses(message, emo.proses)
    rep = message.reply_to_message
    if len(message.command) == 1 and not rep:
        return await pros.edit(
            f"<blockquote>{emo.gagal}<b>Provide text or reply to a message to set as your name.</b></blockquote>"
        )
    elif len(message.command) > 1:
        nama = message.text.split(None, 2)
        name = nama[1]
        namee = nama[2] if len(nama) > 2 else ""

        try:
            await client.update_profile(first_name=name)
            await client.update_profile(last_name=namee)
            return await pros.edit(
                f"<blockquote>{emo.sukses}<b>Successfully changed name to: <code>{name} {namee}</code></b></blockquote>"
            )
        except Exception as e:
            return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b>\n<code>{e}</code></blockquote>")


async def setuname_cmd(client, message):
    emo = Emoji(client)
    await emo.get()

    rep = message.reply_to_message
    if len(message.command) == 1 and not rep:
        return await message.reply(
            f"<blockquote>{emo.gagal}<b>Provide text or reply to a message to set as your username.</b></blockquote>"
        )
    pros = await animate_proses(message, emo.proses)
    if rep:
        uname = rep.text or rep.caption
    elif len(message.command) > 1:
        nama = message.text.split(None, 1)
        uname = nama[1]
    else:
        return await pros.edit(
            f"<blockquote>{emo.gagal}<b>Provide text or reply to a message to set as your username.</b></blockquote>"
        )

    try:
        await client.set_username(username=uname)
        return await pros.edit(
            f"<blockquote>{emo.sukses}<b>Successfully changed username to: <code>{uname}</code></b></blockquote>"
        )
    except (FloodWait, FloodPremiumWait) as e:
        wait = int(e.value)
        await asyncio.sleep(wait)
        await client.set_username(username=uname)
        return await pros.edit(
            f"<blockquote>{emo.sukses}<b>Successfully changed username to: <code>{uname}</code></b></blockquote>"
        )
    except UsernameOccupied:
        return await pros.edit(
            f"<blockquote>{emo.gagal}<b><code>{uname}</code> is already taken by another user.</b></blockquote>"
        )
    except Exception as e:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b>\n<code>{e}</code></blockquote>")


async def remuname_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pros = await animate_proses(message, emo.proses)

    try:
        await client.set_username(username="")
        return await pros.edit(f"<blockquote>{emo.sukses}<b>Username successfully removed.</b></blockquote>")
    except Exception as e:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b>\n<code>{e}</code></blockquote>")


async def setbio_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pros = await animate_proses(message, emo.proses)
    rep = message.reply_to_message
    if len(message.command) == 1 and not rep:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Provide text or reply to a message.</b></blockquote>")
    if rep:
        bio = rep.text or rep.caption
    elif len(message.command) > 1:
        bio = message.text.split(None, 1)[1]
    try:
        await client.update_profile(bio=bio)
        return await pros.edit(
            f"<blockquote>{emo.sukses}<b>Successfully changed bio to: <code>{bio}</b></blockquote>"
        )
    except Exception as e:
        return await pros.edit(f"<blockquote>{emo.gagal}<b>Error:</b> <code>{e}</code></blockquote>")


async def adminlist_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pros = await animate_proses(message, emo.proses)
    a_chats = []
    me = await client.get_me()
    async for dialog in client.get_dialogs():
        try:
            tipe = dialog.chat.type
            if tipe in (enums.ChatType.SUPERGROUP, enums.ChatType.GROUP):
                try:
                    gua = await dialog.chat.get_member(int(me.id))
                    if gua.status in (
                        enums.ChatMemberStatus.OWNER,
                        enums.ChatMemberStatus.ADMINISTRATOR,
                    ):
                        a_chats.append(dialog.chat)
                except Exception:
                    continue
        except Exception:
            continue

    text = "<b>❒ LIST OF GROUPS WHERE YOU ARE AN ADMIN:</b>\n┃\n"
    if len(a_chats) == 0:
        text += "<blockquote><b>You are not an admin anywhere.</b></blockquote>"
        return await pros.edit(f"{text}")
    for count, chat in enumerate(a_chats, 1):
        try:
            title = chat.title
        except Exception:
            title = "Private Group"
        if count == len(a_chats):
            text += f"<blockquote><b>┖ {title}</b>\n</blockquote>"
        else:
            text += f"<blockquote><b>┣ {title}</b>\n</blockquote>"

    if len(text) > 4096:
        with BytesIO(str.encode(text)) as out_file:
            out_file.name = "adminlist.txt"
            await message.reply_document(
                document=out_file,
                caption=f"<blockquote>{emo.sukses}<b>Admin List {client.me.mention}.</b></blockquote>",
            )
            os.remove(out_file)
            return await pros.delete()
    else:
        return await pros.edit(f"{text}")


async def setpp_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    po = "storage/TM_BLACK.png"
    replied = message.reply_to_message
    pros = await animate_proses(message, emo.proses)
    if (
        replied
        and replied.media
        and (
            replied.photo
            or (replied.document and "image" in replied.document.mime_type)
        )
    ):
        prop = await client.download_media(message=replied, file_name=po)
        await client.set_profile_photo(photo=prop)
        await client.send_photo(
            message.chat.id,
            prop,
            caption=f"<blockquote>{emo.sukses}<b>Successfully changed your profile picture.</b></blockquote>",
        )
        if os.path.exists(prop):
            os.remove(prop)
        return await pros.delete()
    else:
        return await pros.edit(
            f"<blockquote>{emo.gagal}<b>Reply to a photo/image, or a document that is a photo/image to set as your profile picture.</b></blockquote>"
        )


async def mestats_cmd(client, message):
    emo = Emoji(client)
    await emo.get()
    pros = await animate_proses(message, emo.proses)
    start = datetime.now()
    pc = 0
    groups = 0
    super_groups = 0
    channels = 0
    bots = 0
    adminchats = 0
    banned = 0
    here = set()
    gue = await client.get_me()

    try:
        async for dialog in client.get_dialogs():
            try:
                if dialog.chat.type == ChatType.PRIVATE:
                    pc += 1
                elif dialog.chat.type == ChatType.BOT:
                    bots += 1
                elif dialog.chat.type == ChatType.GROUP:
                    groups += 1
                    ucel = await dialog.chat.get_member(int(gue.id))
                    if ucel.status in (
                        ChatMemberStatus.OWNER,
                        ChatMemberStatus.ADMINISTRATOR,
                    ):
                        adminchats += 1
                elif dialog.chat.type == ChatType.SUPERGROUP:
                    super_groups += 1
                    user_s = await dialog.chat.get_member(int(gue.id))
                    if user_s.status in (
                        ChatMemberStatus.OWNER,
                        ChatMemberStatus.ADMINISTRATOR,
                    ):
                        adminchats += 1
                elif dialog.chat.type == ChatType.CHANNEL:
                    channels += 1
            except ChannelPrivate:
                banned += 1
                here.add(dialog.chat.id)
                continue
            except UserNotParticipant:
                await client.leave_chat(dialog.chat.id)
                print(f"Bot is not a member of this chat, leaving: {dialog.chat.id}")
                continue
    except ChannelPrivate:
        banned += 1
        here.add(dialog.chat.id)
    except Exception as e:
        print(f"An error occurred: {str(e)} {dialog.chat.id}")

    end = datetime.now()
    waktu = (end - start).seconds

    if not here:
        here = 0

    return await pros.edit(
        f"""
<blockquote expandable>{emo.sukses}<b>Successfully extracted your data in <code>{waktu}</code> seconds:

• <code>{pc}</code> Private Messages.
• <code>{groups}</code> Groups.
• <code>{super_groups}</code> Super Groups.
• <code>{channels}</code> Channels.
• <code>{adminchats}</code> Admin Chats.
• <code>{bots}</code> Bots.
• <code>{banned}</code> Problematic Groups.

I encountered issues with these chats: 
• <code>{here}</code></b></blockquote>
"""
    )


async def react_cmd(client, message):
    em = Emoji(client)
    await em.get()

    proses = await animate_proses(message, em.proses)
    sukses = 0
    failed = 0

    if len(message.command) not in [2, 3]:
        return await proses.edit(
            f"<blockquote>{em.gagal}**Please use format `{message.text.split()[0]}` [@username/chat_id] [emoji/random]**</blockquote>"
        )

    task_id = task.start_task()
    try:
        if len(message.command) == 3:
            chat_id = message.text.split()[1]
            emoji = message.text.split()[2]
        else:
            chat_id = message.chat.id
            emoji = message.text.split()[1]

        if emoji.lower() == "random":
            emoji = random.choice(RANDOM_EMOJIS)

        prefix = client.get_prefix(client.me.id)

        await proses.edit(
            f"<blockquote expandable>{em.proses}<i>Task reaction running #<code>{task_id}</code>. Type <code>{prefix[0]}cancel {task_id}</code> to stop reaction!</i></blockquote>"
        )
        for user_id in session.get_list():
            c = session.get_session(user_id)
            if c:
                async for m in c.get_chat_history(chat_id):
                    if not task.is_active(task_id):
                        return await proses.edit(
                            f"<blockquote>{em.gagal}**Task #{task_id} has been cancelled!**</blockquote>"
                        )
                    await asyncio.sleep(0.5)
                    message_id = m.id
                    await asyncio.sleep(0.5)
                    try:
                        await c.send_reaction(
                            chat_id=chat_id, message_id=message_id, emoji=emoji
                        )
                        sukses += 1
                    except Exception:
                        failed += 1
    except Exception as er:
        return await proses.edit(f"<blockquote>{em.gagal}**ERROR:** {str(er)}</blockquote>")
    finally:
        task.end_task(task_id)
    return await proses.edit(
        f"<blockquote expandable><b>{em.sukses}Succesfully send reaction to chat: {chat_id}, emoji: {emoji}.\n\nSucces: {sukses}, Failed: {failed}.</b></blockquote>"
    )


async def react2_cmd(client, message):
    em = Emoji(client)
    await em.get()

    reply = message.reply_to_message or message
    proses = await animate_proses(message, em.proses)
    sukses = 0
    failed = 0

    if len(message.command) < 2:
        return await proses.edit(
            f"<blockquote>{em.gagal}**Please use format `{message.text.split()[0]}` [emoji/random]**</blockquote>"
        )

    task_id = task.start_task()
    try:
        chat_id = message.chat.id
        emoji = message.text.split()[1]

        if emoji.lower() == "random":
            emoji = random.choice(RANDOM_EMOJIS)

        prefix = client.get_prefix(client.me.id)

        await proses.edit(
            f"<blockquote expandable>{em.proses}<i>Task reaction running #<code>{task_id}</code>. Type <code>{prefix[0]}cancel {task_id}</code> to stop reaction!</i></blockquote>"
        )
        try:
            for user_id in session.get_list():
                c = session.get_session(user_id)
                if c:
                    message_id = reply.id
                    await asyncio.sleep(0.5)
                    await c.send_reaction(
                        chat_id=chat_id, message_id=message_id, emoji=emoji
                    )
                    sukses += 1
        except Exception:
            failed += 1
    except Exception as er:
        return await proses.edit(f"<blockquote>{em.gagal}**ERROR:** {str(er)}</blockquote>")
    finally:
        task.end_task(task_id)
    return await proses.edit(
        f"<blockquote expandable><b>{em.sukses}Succesfully send reaction to chat: {chat_id}\nEmoji: {emoji}\nSucces: {sukses}, Failed: {failed}.</b></blockquote>"
    )


async def sangmata_cmd(client, message):
    em = Emoji(client)
    await em.get()
    reply = message.reply_to_message
    try:
        if len(message.command) < 2 and not reply:
            return await message.reply(
                f"<blockquote>**{em.gagal}Please reply to a message or provide a username/id**</blockquote>"
            )
        if reply:
            user = reply.from_user.id
        else:
            target = message.text.split()[1]
            if target.startswith("@") or not target.isdigit():
                user = (await client.get_users(target)).id
            else:
                user = int(target)

        proses = await animate_proses(message, em.proses)
        sg = "@SangMata_BOT"
        try:
            a = await client.send_message(sg, user)
            await asyncio.sleep(1)
            await a.delete()
        except Exception as e:
            return await proses.edit(f"<blockquote>**{em.gagal}{str(e)}**</blockquote>")
        async for respon in client.search_messages(a.chat.id):
            if respon.text == None:
                continue
            if not respon:
                return await message.reply(f"<blockquote>**{em.gagal}No response from Sangmata**</blockquote>")
            elif respon:
                await message.reply(f"<blockquote>{em.sukses} {respon.text}</blockquote>")
                break
        await proses.delete()
        try:
            user_info = await client.resolve_peer(sg)
            return await client.invoke(
                raw.functions.messages.DeleteHistory(
                    peer=user_info, max_id=0, revoke=True
                )
            )
        except Exception:
            pass
    except Exception as er:
        return await message.reply(f"<blockquote>**ERROR**: {str(er)}</blockquote>")


async def story_cmd(client, message):
    em = Emoji(client)
    await em.get()

    proses = await animate_proses(message, em.proses)
    args = ["cek", "del", "get", "post"]
    query = message.command[1]
    if len(message.command) < 2 and query not in args:
        return await proses.edit(
            f"<blockquote>{em.gagal}<b>Please give query [post, cek, get, or del]</b></blockquote>"
        )
    prefix = client.get_prefix(client.me.id)
    if query == "cek":
        text = f"<blockquote>{em.owner}<b>Your stories:</b>\n\n</blockquote>"
        async for story in client.get_all_stories():
            if story.from_user.id == client.me.id:
                story_link = await client.export_story_link("me", story.id)
                text += f"<blockquote expandable>{em.sukses}<b>• Story ID: `{story.id}` | Story Link: [Click Here]({story_link})</b>\n</blockquote>"
        await message.reply(text, disable_web_page_preview=True)
        return await proses.delete()

    elif query == "del":
        if len(message.command) < 3:
            return await proses.edit(
                f"<blockquote expandable><b>{em.gagal} That's not how it works!! Provide your story ID.\nExample: `{prefix[0]}story del` 5\n\nOr you can type `{prefix[0]}story cek` to see your story IDs!! </b></blockquote>"
            )
        story_id = message.text.split()[2]
        if not story_id.isnumeric():
            return await proses.edit(
                f"<blockquote>{em.gagal}<b>ID should be a number, not letters or symbols.</b></blockquote>"
            )
        await client.delete_stories(story_ids=int(story_id))
        return await proses.edit(
            f"<blockquote>{em.sukses}<b>Successfully deleted Story ID: `{story_id}`!!</b></blockquote>"
        )

    elif query == "get":
        if len(message.command) < 3:
            return await proses.edit(f"<blockquote>{em.gagal}**Please give link story!**</blockquote>")
        link = message.text.split()[2]
        if "/s/" not in link:
            return await proses.edit(
                f"<blockquote>{em.gagal}<b>Please provide a valid Telegram stories link!!</b></blockquote>"
            )
        user, story_id = Tools.extract_story_link(link)
        story = await client.get_stories(user, story_id)
        await Tools.download_media(story, client, proses, message, True)
        return await proses.delete()

    elif query == "post":
        reply = message.reply_to_message
        if not reply or reply and not reply.media:
            return await proses.edit(f"<blockquote>{em.gagal}**Please reply to photo or video**</blockquote>")
        kwargs = reply.photo.file_id or reply.video.file_id
        text = reply.caption or ""
        try:
            target = "me" if len(message.command) < 3 else message.text.split()[2]
            story = await client.send_story(
                target, kwargs, caption=text, privacy=StoriesPrivacyRules.PUBLIC
            )
            this = await client.export_story_link("me", story.id)
            return await proses.edit(
                f"<blockquote>{em.sukses}<b>Succesfully upload to [Story]({this})!</b></blockquote>",
                disable_web_page_preview=True,
            )
        except Exception as e:
            logger.error(f"Error: {traceback.format_exc()}")
            return await proses.edit(f"<blockquote>{em.gagal}**ERROR:** {str(e)}</blockquote>")
    else:
        return await proses.edit(
            f"<blockquote>{em.gagal}<b>Please give query [post, cek, get, or del]</b></blockquote>"
        )


async def ignore_cmd(client, message):
    data_module = await dB.get_var(client.me.id, "IGNORE_MODULES") or []
    data_sudo = await dB.get_var(client.me.id, "IGNORE_SUDO") or []
    if message.command[0] == "ignore":
        if len(message.command) < 3:
            if len(message.command) < 2:
                return await message.reply("<blockquote>**Please give plugins name for disable**</blockquote>")
            name = message.text.split(None, 1)[1]
            ada = next((n for n in HELPABLE if name.lower() == n), None)
            if ada is None:
                return await message.reply(f"<blockquote>**Plugins {name} is not defined**</blockquote>")
            if name.lower() in data_module:
                return await message.reply(f"<blockquote>**Plugins {name} already disabled**</blockquote>")
            data_module.append(name.lower())
            await dB.set_var(client.me.id, "IGNORE_MODULES", data_module)
            return await message.reply(f"<blockquote>**Disabled plugins: `{name}`.**</blockquote>")

        elif len(message.command) > 2:
            if message.command[1] == "sudo":
                name = message.text.split(None, 2)[2]
                ada = next((n for n in HELPABLE if name.lower() == n), None)
                if ada is None:
                    return await message.reply(f"<blockquote>**Plugins `{name}` is not defined**</blockquote>")
                if name.lower() in data_sudo:
                    return await message.reply(
                        f"<blockquote>**Plugins `{name}` for sudo already disabled**</blockquote>"
                    )
                data_sudo.append(name.lower())
                await dB.set_var(client.me.id, "IGNORE_SUDO", data_sudo)
                return await message.reply(f"<blockquote>**Disabled plugins: `{name}` for sudo.**</blockquote>")
            else:
                return await message.reply("<blockquote>**Please give plugins name for disable**</blockquote>")
        else:
            return await message.reply("<blockquote>**Please give plugins name for disable**</blockquote>")

    elif message.command[0] == "reignore":
        if len(message.command) < 3:
            if len(message.command) < 2:
                return await message.reply("<blockquote>**Please give plugins name for enable**</blockquote>")
            name = message.text.split(None, 1)[1]
            ada = next((n for n in HELPABLE if name.lower() == n), None)
            if ada is None:
                return await message.reply(f"<blockquote>**Plugins {name} is not defined**</blockquote>")
            if name.lower() not in data_module:
                return await message.reply(f"<blockquote>**Plugins {name} already enable**</blockquote>")
            data_module.remove(name.lower())
            await dB.set_var(client.me.id, "IGNORE_MODULES", data_module)
            return await message.reply(f"<blockquote>**Enabled plugins: `{name}`.**</blockquote>")

        elif len(message.command) > 2:
            if message.command[1] == "sudo":
                name = message.text.split(None, 2)[2]
                ada = next((n for n in HELPABLE if name.lower() == n), None)
                if ada is None:
                    return await message.reply(f"<blockquote>**Plugins `{name}` is not defined**</blockquote>")
                if name.lower() not in data_sudo:
                    return await message.reply(
                        f"<blockquote>**Plugins `{name}` for sudo already enable**</blockquote>"
                    )
                data_sudo.remove(name.lower())
                await dB.set_var(client.me.id, "IGNORE_SUDO", data_sudo)
                return await message.reply(f"<blockquote>**Enabled plugins: `{name}` for sudo.**</blockquote>")
            else:
                return await message.reply("<blockquote>**Please give plugins name for enable**</blockquote>")
        else:
            return await message.reply("<blockquote>**Please give plugins name for enable**</blockquote>")

    elif message.command[0] == "ignored":
        if len(message.command) < 2:
            if len(data_module) == 0:
                return await message.reply(f"<blockquote>**You dont have disabled plugins.**</blockquote>")
            msg = "<blockquote>**List disabled plugins:**\n\n"
            for count, name in enumerate(data_module, 1):
                msg += f"**{count}**. `{name}`\n</blockquote>"
            return await message.reply(msg)
        else:
            if message.command[1] == "sudo":
                if len(data_sudo) == 0:
                    return await message.reply(
                        f"<blockquote>**You dont have disabled plugins for sudo.**</blockquote>"
                    )
                msg = "<blockquote>**List disabled plugins for sudo:**\n\n"
                for count, name in enumerate(data_sudo, 1):
                    msg += f"**{count}**. `{name}`\n</blockquote>"
                return await message.reply(msg)
            else:
                return
