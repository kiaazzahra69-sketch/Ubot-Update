from command import maker_img_cmd
from helpers import CMD

_MODULES_ = "Maker"

_HELP_ = """<blockquote>Command Help **Maker**</blockquote>

<blockquote expandable>--**Basic Commands**--

    **You can make effect for photo**

        `{0}maker` (command) (reply photo)

    **Available command:**

    - `xnxx`

    - `sertifikat`
</blockquote>

<b>{1}</b>
"""

IS_PRO = True

@CMD.UBOT("maker")
async def maker_handler(client, message):
    prefix = "/"  # contoh prefix
    additional_info = "Silakan reply foto dengan perintah ini untuk membuat efek."

    if message.reply_to_message and message.reply_to_message.photo:
        return await maker_img_cmd(client, message)
    else:
        help_text = _HELP_.format(prefix, additional_info)
        await message.reply(help_text, parse_mode="HTML")
