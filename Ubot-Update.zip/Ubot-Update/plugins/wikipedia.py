import aiohttp
import urllib.parse
from helpers import Emoji, CMD
from clients import navy

__MODULES__ = "Wikipedia"
__HELP__ = """<blockquote>Command Help **Wikipedia**</blockquote>
<blockquote expandable>--**Pro Commands**--

    **Search Wikipedia**
        `{0}wiki` (query)</blockquote>
<b>   {1}</b>
"""

IS_PRO = True


async def wikipedia(query, lang="id"):
    try:
        query = urllib.parse.quote(query.strip())
        url = (
            f"https://{lang}.wikipedia.org/w/api.php"
            f"?action=query&prop=extracts|pageimages&format=json"
            f"&exintro=1&explaintext=1&titles={query}&redirects=1&pithumbsize=500"
        )

        async with aiohttp.ClientSession() as session:
            async with session.get(url, allow_redirects=True) as response:
                if response.status != 200:
                    return {"status": response.status, "Pesan": "Tidak Ditemukan"}

                data = await response.json()
                pages = data.get("query", {}).get("pages", {})

                if not pages:
                    return {"status": 404, "Pesan": "Tidak Ditemukan"}

                # ambil halaman pertama dari pages
                page = list(pages.values())[0]

                title = page.get("title", "Tanpa Judul")
                extract = page.get("extract", "").strip()
                thumb = page.get("thumbnail", {}).get(
                    "source", "https://k.top4top.io/p_2121ug8or0.png"
                )

                if not extract:
                    return {"status": 404, "Pesan": "Konten tidak ditemukan"}

                return {
                    "status": 200,
                    "result": {
                        "judul": title,
                        "thumb": thumb,
                        "isi": extract,
                    },
                }

    except Exception as e:
        return {"status": 404, "Pesan": str(e)}


@CMD.UBOT("wiki|wikipedia")
async def wiki_handler(client, message, *args):
    text = message.text.split(maxsplit=1)[1] if len(message.command) > 1 else None
    if not text:
        await message.reply_text(
            "<blockquote><b><i>contoh : .wiki indonesia</i></b></blockquote>"
        )
        return

    # coba ambil dari Wikipedia Indonesia
    res = await wikipedia(text, "id")

    # kalau gagal, coba Wikipedia Inggris
    if res["status"] != 200:
        res = await wikipedia(text, "en")

    if res["status"] == 200:
        result = res["result"]
        caption = f"""
<b>Judul:</b> {result['judul']}

<b>Penjelasan:</b>
{result['isi']}
"""

        if len(caption) > 1024:
            caption = caption[:1000] + "..."

        await client.send_photo(
            message.chat.id,
            photo=result["thumb"],
            caption=caption,
        )
    else:
        await message.reply_text(
            f"<blockquote><b><i>{res.get('Pesan', 'Tidak Ditemukan')}</i></b></blockquote>"
        )