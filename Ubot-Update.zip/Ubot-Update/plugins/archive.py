from clients import navy
from helpers import CMD, Emoji, animate_proses

__MODULES__ = "Archive"
__HELP__ = """<blockquote>Command Help **Archive**</blockquote>
    
<blockquote><u>**Archive all chat**</u>
    <u>**You can archive all chat**</u>
        `{0}arsip`
        `{0}unarsip`</blockquote>
    
<b>   {1}</b>
"""

IS_PRO = True


@CMD.UBOT("archive|arsip")
async def _(client, message):
    em = Emoji(client)
    await em.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await em.get_costum_text()
    pros = await animate_proses(message, em.proses)

    memeg = message.command[1]
    raxxy = await client.get_chats_dialog(memeg)
    for ktl in raxxy:
        await client.archive_chats(ktl)

    return await pros.edit(
        f"<blockquote><b>{em.sukses}Berhasil mengarsipkan semua {len(raxxy)} {memeg}.</b></blockquote>"
    )


@CMD.UBOT("unarchive|unarsip")
async def unarchive_user(client, message):
    em = Emoji(client)
    await em.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await em.get_costum_text()
    pros = await animate_proses(message, em.proses)

    memeg = message.command[1]
    raxxy = await client.get_chats_dialog(memeg)
    for ktl in raxxy:
        await client.unarchive_chats(ktl)

    return await pros.edit(
        f"<blockquote><b>{em.sukses}Berhasil meng-unarsipkan semua {len(raxxy)} {memeg}.</b></blockquote>"
    )