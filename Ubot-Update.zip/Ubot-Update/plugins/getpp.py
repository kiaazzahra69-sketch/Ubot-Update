from pyrogram import Client, filters
from pyrogram.errors import (
    UsernameNotOccupied,
    UserNotParticipant,
    PeerIdInvalid
)

from helpers import Emoji, CMD
from clients import navy

__MODULES__ = "GetPP"
__HELP__ = """<blockquote>Command Help GetPP**</blockquote>

<blockquote expandable>**Get pp from user**
    **Get pp from user or group**
        `{0}getpp` `{0}getprofile` (reply)</blockquote>

<b>   {1}</b>
"""

IS_PRO = True


@CMD.UBOT("getpp|getprofile")
async def get_profile_pic(client, message, *args):
    em = Emoji(client)
    await em.get()
    target = None

    if message.reply_to_message:
        target = message.reply_to_message.from_user.id

    elif len(message.command) > 1:
        target = message.command[1]

    else:
        target = message.chat.id
        
    if not target:
        return await message.reply_text("<blockquote>{em.gagal}**__Gunakan `/getpp @username`, reply user, atau kirim `.getpp` di grup/channel untuk ambil PP.__**</blockquote>")

    try:
        async for photo in client.get_chat_photos(target, limit=1):  # Ambil 1 foto terbaru
            await client.send_photo(
                message.chat.id,
                photo=photo.file_id,
                caption="<pre>Done✅</pre>"
            )
            return

        await message.reply_text("<blockquote>{em.gagal}**__User/grup tidak memiliki foto profil__**.</blockquote>")

    except (UsernameNotOccupied, UserNotParticipant, PeerIdInvalid):
        await message.reply_text("<blockquote>{em.gagal}**__Akun atau grup tidak ditemukan.__**</blockquote>")
    except Exception as e:
        await message.reply_text(f"<blockquote>{em.gagal}**__Terjadi kesalahan: {str(e)}__**</blockquote>")
