import os
import json
import asyncio
import psutil
# import speedtest
from speedtest import Speedtest
import random

from datetime import datetime
from gc import get_objects
from time import time
from config import HELPABLE, LOG_SELLER, BOT_NAME, OWNER_ID
from pyrogram.raw import *
from pyrogram.raw.functions import Ping
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from clients import navy
from helpers import (Basic_Effect, CMD, Emoji, Premium_Effect, Tools,
                     animate_proses, get_time, start_time, task)
from logs import logger

__MODULES__ = "Ping2"
__HELP__ = """<blockquote>Command Help Ping2**</blockquote>

<blockquote expandable>**Get ping**
    **Ping Animate**
        `{0}ping1`
        `{0}ping2`
        `{0}p`</blockquote>

<b>   {1}</b>
"""

IS_PRO = True
    
class speed:
    SpeedTest = (
        "Speedtest started at `{start}`\n"
        "Ping ➠ `{ping}` ms\n"
        "Download ➠ `{download}`\n"
        "Upload ➠ `{upload}`\n"
        "ISP ➠ __{isp}__"
    )

    NearestDC = "Country: `{}`\n" "Nearest Datacenter: `{}`\n" "This Datacenter: `{}`"

async def _(client, message):
    em = Emoji(client)
    await em.get()
    pong_, uptime_, owner_, ubot_, proses_, sukses_ = await em.get_costum_text()
    proses = await message.reply(f"<blockquote>{em.proses}**Ping...**</blockquote>")
    out, _ = await Tools.bash("ping -c 2 165.22.106.160")
    matches = re.findall(r"time=([\d.]+)\s?ms", out)
    ping_result = f"{matches[-1]}"
    upnya = await get_time((time() - start_time))
    plan_mode = await dB.get_var(client.me.id, "plan")
    if plan_mode in ["is_pro", "basic"]:
        _ping = (
            f"<blockquote><b>{em.ping}{pong_}:</b> {ping_result} ms\n"
            f"<b>{em.uptime}{uptime_}:</b> {upnya}\n"
            f"<b>{em.owner}{owner_}</b></blockquote>"
        )
    else:
        _ping = f"<blockquote><b>{em.ping}{pong_}:</b> {ping_result} ms\n</blockquote>"

    if message._client.me.is_premium:
        effect_id = random.choice(Premium_Effect)
    else:
        effect_id = random.choice(Basic_Effect)
    await proses.delete()
    if message.chat.type == enums.ChatType.PRIVATE:
        return await message.reply(_ping, effect_id=effect_id)
    else:
        return await message.reply(_ping)

@CMD.UBOT("ping1")
async def _(client, message, *args):
    start = datetime.now()
    await client.invoke(Ping(ping_id=0))
    end = datetime.now()
    uptime = await get_time((time() - start_time))
    delta_ping_formatted = round((end - start).microseconds / 10000, 2)
    xx = await message.edit("𖣐")
    await asyncio.sleep(0.3)
    await xx.edit("𖣐𖣐")
    await asyncio.sleep(0.3)
    await xx.edit("𖣐𖣐𖣐")
    await asyncio.sleep(0.3)
    await xx.edit("𖣐𖣐𖣐𖣐")
    await asyncio.sleep(0.3)
    await xx.edit("𖣐𖣐𖣐𖣐𖣐")
    await asyncio.sleep(0.3)
    await xx.edit("⚡")
    await asyncio.sleep(0.5)
    babi = client.me.is_premium
    if babi:
        _ping = f"""
<blockquote>⎆ <emoji id=5260547274957672345>🎲</emoji> ᴘɪɴɢ : {str(delta_ping_formatted).replace('.', ',')} ms
⎆ <emoji id=5235948055928262102>⭐</emoji> ᴜᴘᴛɪᴍᴇ : {uptime}
⎆ <emoji id=5204015897500469606>😢</emoji> ᴋɪɴɢ : <code>{client.me.mention}</code>
⎆ <emoji id=5194979342144260681>😂</emoji> ᴡᴀʀʀɪᴏʀ : <code>{BOT_NAME}</code></blockquote>
"""
        await message.reply(_ping)
    else:
        _ping = f"""
<blockquote>⎆ <emoji id=5260547274957672345>🎲</emoji> ᴘɪɴɢ : {str(delta_ping_formatted).replace('.', ',')} ms
⎆ <emoji id=5235948055928262102>⭐</emoji> ᴜᴘᴛɪᴍᴇ : {uptime}
⎆ <emoji id=5204015897500469606>😢</emoji> ᴋɪɴɢ : <code>{client.me.mention}</code>
⎆ <emoji id=5194979342144260681>😂</emoji> ᴡᴀʀʀɪᴏʀ : <code>{BOT_NAME}</code></blockquote>
"""
        await message.reply(_ping)

@CMD.UBOT("ping2")
async def _(client, message, *args):
    start = datetime.now()
    await client.invoke(Ping(ping_id=0))
    end = datetime.now()
    uptime = await get_time((time() - start_time))
    delta_ping_formatted = round((end - start).microseconds / 10000, 2)
    xx = await message.edit("★ PING ★")
    await asyncio.sleep(0.5)
    await xx.edit("★★ PING ★★")
    await asyncio.sleep(0.5)
    await xx.edit("★★★ PING ★★★")
    await asyncio.sleep(0.5)
    await xx.edit("★★★★ PING ★★★★")
    await asyncio.sleep(0.5)
    await xx.edit("✦҈͜͡➳ PONG!")
    await asyncio.sleep(0.5)
    await xx.edit("🌩")
    await asyncio.sleep(0.5)
    babi = client.me.is_premium
    if babi:
        _ping = f"""
<blockquote><emoji id=5897929355216034070>🤩</emoji> ❃ **Ping !!**
{str(delta_ping_formatted).replace('.', ',')} ms

<emoji id=5900041834880571364>😈</emoji> ❃ **Uptime -**
{uptime}

<emoji id=5897741587835786345>🔥</emoji> **✦҈͜͡➳ Master :**
<code>{client.me.mention}</code>

<emoji id=5900145373657176313>😂</emoji> **✦҈͜͡➳ Bot :**
<code>{BOT_NAME}</code></blockquote>
"""
        await message.reply(_ping)
    else:
        _ping = f"""
<blockquote><emoji id=5897929355216034070>🤩</emoji> ❃ **Ping !!**
{str(delta_ping_formatted).replace('.', ',')} ms

<emoji id=5900041834880571364>😈</emoji> ❃ **Uptime -**
{uptime}

<emoji id=5897741587835786345>🔥</emoji> **✦҈͜͡➳ Master :**
<code>{client.me.mention}</code>

<emoji id=5900145373657176313>😂</emoji> **✦҈͜͡➳ Bot :**
<code>{BOT_NAME}</code></blockquote>
"""
        await message.reply(_ping)

@CMD.UBOT("p")
async def _(client, message, *args):
    start = datetime.now()
    await client.invoke(Ping(ping_id=0))
    end = datetime.now()
    uptime = await get_time((time() - start_time))
    delta_ping_formatted = round((end - start).microseconds / 10000, 2)
    xx = await message.edit("▩▩▩▩▩<emoji id=5474431664136407043>🚬</emoji>")
    await asyncio.sleep(0.3)
    await xx.edit("▩▩▩▩■<emoji id=5474431664136407043>🚬</emoji>")
    await asyncio.sleep(0.3)
    await xx.edit("▩▩▩■■<emoji id=5474431664136407043>🚬</emoji>")
    await asyncio.sleep(0.3)
    await xx.edit("▩▩■■■<emoji id=5474431664136407043>🚬</emoji>")
    await asyncio.sleep(0.3)
    await xx.edit("▩■■■■<emoji id=5474431664136407043>🚬</emoji>")
    await asyncio.sleep(0.3)
    await xx.edit("■■■■■<emoji id=5474431664136407043>🚬</emoji>")
    await asyncio.sleep(0.3)
    await xx.edit("<emoji id=5229011542011299168>👑</emoji>")
    await asyncio.sleep(0.5)
    babi = client.me.is_premium
    if babi:
        _ping = f"""
<blockquote>⎆<emoji id=5963085452205362622>🤯</emoji> ᴘɪɴɢ : {str(delta_ping_formatted).replace('.', ',')} ms
⎆ <emoji id=5456258235872863332>🎁</emoji> ᴜᴘᴛɪᴍᴇ : {uptime}
⎆ <emoji id=5870836972095803022>😎</emoji> ᴋɪɴɢᴢ : <code>{client.me.mention}</code>
⎆ <emoji id=5463335865235288297>🤬</emoji> ᴡᴀʀʀɪᴏʀ : <code>{BOT_NAME}</code></blockquote>
"""
        await message.reply(_ping)
    else:
        _ping = f"""
<blockquote>⎆<emoji id=5963085452205362622>🤯</emoji> ᴘɪɴɢ : {str(delta_ping_formatted).replace('.', ',')} ms
⎆ <emoji id=5456258235872863332>🎁</emoji> ᴜᴘᴛɪᴍᴇ : {uptime}
⎆ <emoji id=5870836972095803022>😎</emoji> ᴋɪɴɢᴢ : <code>{client.me.mention}</code>
⎆ <emoji id=5463335865235288297>🤬</emoji> ᴡᴀʀʀɪᴏʀ : <code>{BOT_NAME}</code></blockquote>
"""
        await message.reply(_ping)
        