from clients import navy
from command import auto_reply_trigger, chatbot_cmd, chatbot_auto_trigger
from helpers import CMD

__MODULES__ = "Chatbot"
__HELP__ = """<blockquote>Command Help **chatbot**</blockquote>
<blockquote expandable>--**Basic Commands**--

    <blockquote expandable>**You can turned on chatbot in group chat**
        `{0}chatbot on`
    **You can turned off chatbot in group chat**
        `{0}chatbot off`
    **You can turned on chatbot from admins in group chat**
        `{0}chatbot admin on`
    **You can turned off chatbot from admins in group chat**
        `{0}chatbot admin off`
    **You can turned on chatbot for allchats if someone reply your messages**
        `{0}chatbot reply on`
    **You can turned off chatbot for allchats if someone reply your messages**
        `{0}chatbot reply off`
    **You can ignore chatbot for user in group chat**
        `{0}chatbot ignore` (userID/reply user)
    **You can reignore chatbot for user  in group chat**
        `{0}chatbot reignore` (userID/reply user)
    **You can check status on database**
        `{0}chatbot status`
    **You can set role for chatbot**
        `{0}chatbot role` (reply to text)</blockquote>

    <blockquote expandable>**Auto reply mode**
    **Can be activated in a group or using a group ID in private chat**
        `{0}chatbot auto on` (groupId -100xxx)
        `{0}chatbot auto off` (grouId -100xxx)
    **You can check auto status on database**
        `{0}chatbot auto status`</blockquote>

**Note:** Default mode works only if someone replies to your message.
Auto mode will reply to every message in the group.</blockquote>
<b>   {1}</b>
"""

IS_PRO = True


@CMD.UBOT("chatbot")
async def _(client, message):
    return await chatbot_cmd(client, message)


@CMD.NO_CMD("CHATBOT", navy)
async def _(client, message):
    await auto_reply_trigger(client, message)

@CMD.NO_CMD("AUTO_CHATBOT", navy)
async def _(client, message):
    await chatbot_auto_trigger(client, message)