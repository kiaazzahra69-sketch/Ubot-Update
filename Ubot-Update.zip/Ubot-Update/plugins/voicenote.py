import asyncio
import time
import random
import traceback
import os
import uuid
import httpx
import aiofiles
from mutagen import File as MutagenFile
from mutagen.id3 import ID3NoHeaderError

from pyrogram import enums
from config import OPENAI_API_KEY
from helpers import CMD, Tools, Emoji
from database import dB
from logs import logger
from clients import navy

__MODULES__ = "Auto VN"
__HELP__ = """<blockquote>Command Help **Auto Voice Note**</blockquote>

<blockquote expandable><u>**Aktifkan / Matikan Mode Auto VN di Grup**</u>
    `{0}vnchat on | off | status`
    `{0}vnchat on -100xxxxxxxxxx` (aktifkan di grup lain dari private chat)</blockquote>

<blockquote expandable><u>**Atur Model Suara yang Dipakai**</u>
    `{0}setvn <nama_voice>` — ubah model suara (contoh: id-ID-GadisNeural)
    `{0}getvn` — cek suara yang sedang digunakan
    `{0}vnget` — lihat daftar lengkap suara dari server TTS lokal</blockquote>

<blockquote expandable><u>**Deskripsi Fitur**</u>
    Auto VN akan otomatis membalas pesan teks dengan voice note.
    Gunakan perintah di atas untuk mengatur model suara dan status per grup.</blockquote>

<b>{1}</b>
"""

IS_PRO = True

# USER_DELAY = 15   # delay antar pesan per user
# GROUP_DELAY = 8   # delay antar pesan per grup


# last_user_reply = {}
# last_group_reply = {}



@CMD.UBOT("vnchat")
async def vnchat_toggle(client, message):
    """Hidupkan / matikan auto voice note di grup"""
    em = Emoji(client)
    await em.get()

    args = client.get_text(message)
    if not args:
        return await message.reply(
            f"<blockquote>{em.gagal}Gunakan: `{message.text.split()[0]} on | off | status | on -100xxxxx`</blockquote>"
        )

    parts = args.split()
    cmd = parts[0].lower()
    chat_id = message.chat.id
    key = "VNCHAT_AUTO"

    target_chat_id = chat_id
    if len(parts) > 1 and parts[1].lstrip("-").isdigit():
        try:
            target_chat_id = int(parts[1])
        except Exception:
            return await message.reply(
                f"<blockquote>{em.gagal}ID grup tidak valid.</blockquote>"
            )

    if message.chat.type == "private" and len(parts) == 1:
        return await message.reply(
            f"<blockquote>{em.gagal}Perintah ini dijalankan di private chat.\nGunakan format: `{message.text.split()[0]} on -100xxxxxxxxxx`</blockquote>"
        )

    group_name = "Unknown"
    try:
        chat_info = await client.get_chat(target_chat_id)
        group_name = chat_info.title or str(target_chat_id)
    except Exception:
        group_name = str(target_chat_id)

    if cmd == "on" and target_chat_id == chat_id and message.chat.type != "private":
        try:
            member = await client.get_chat_member(target_chat_id, client.me.id)
            perms = getattr(member, "privileges", None)
            if perms:
                can_voice = getattr(perms, "can_send_voice_notes", True)
                can_audio = getattr(perms, "can_send_audios", True)
                if not can_voice or not can_audio:
                    return await message.reply(
                        f"<blockquote>{em.gagal}Saya tidak punya izin untuk mengirim voice note atau audio di grup ini </blockquote>"
                    )
        except Exception as e:
            print(f"[VNCHAT WARN] Gagal memeriksa izin voice/audio: {e}")

    if cmd == "on":
        active = await dB.get_list_from_var(client.me.id, key)
        if target_chat_id in active:
            return await message.reply(
                f"<blockquote>{em.gagal}Auto VN sudah aktif di <b>{group_name}</b> (`{target_chat_id}`).</blockquote>"
            )

        await dB.add_to_var(client.me.id, key, target_chat_id)
        return await message.reply(
            f"<blockquote>{em.sukses}Auto Voice aktif di <b>{group_name}</b> (`{target_chat_id}`)</blockquote>"
        )

    elif cmd == "off":
        active = await dB.get_list_from_var(client.me.id, key)
        if target_chat_id not in active:
            return await message.reply(
                f"<blockquote>{em.gagal}Auto VN belum aktif di <b>{group_name}</b> (`{target_chat_id}`).</blockquote>"
            )

        await dB.remove_from_var(client.me.id, key, target_chat_id)
        return await message.reply(
            f"<blockquote>{em.sukses}Auto Voice dimatikan di <b>{group_name}</b> (`{target_chat_id}`)</blockquote>"
        )

    elif cmd == "status":
        active = await dB.get_list_from_var(client.me.id, key)
        if not active:
            return await message.reply("<blockquote>Tidak ada grup yang aktif Auto VN.</blockquote>")

        text = "<blockquote expandable><b>📻 Grup dengan Auto VN aktif:</b>\n\n"
        for i, cid in enumerate(active, 1):
            try:
                chat = await client.get_chat(cid)
                voice = await dB.get_var(client.me.id, f"VNVOICE_{cid}") or "id-ID-GadisNeural"
                text += f"{i}. {chat.title} (`{cid}`) - 🎙️ {voice}\n"
            except Exception:
                text += f"{i}. (Unknown Chat) `{cid}`\n"

        text += "</blockquote>"  # ✅ tutup blockquote di akhir

        return await message.reply(text)

    else:
        return await message.reply(
            f"<blockquote>{em.gagal}Gunakan: `{message.text.split()[0]} on | off | status | on -100xxxxx`</blockquote>"
        )


@CMD.UBOT("setvn")
async def set_vnvoice(client, message):
    """Atur model suara VN untuk grup"""
    em = Emoji(client)
    await em.get()

    args = client.get_text(message)
    if not args:
        return await message.reply(
            f"<blockquote>{em.gagal}Gunakan: `{message.text.split()[0]} id-ID-GadisNeural`</blockquote>"
        )

    chat_id = message.chat.id
    voice_model = args.strip()

    # gunakan set_var bukan set_key
    await dB.set_var(client.me.id, f"VNVOICE_{chat_id}", voice_model)

    return await message.reply(
        f"<blockquote>{em.sukses}Model suara untuk grup ini diatur ke <b>{voice_model}</b></blockquote>"
    )


async def auto_vn_reply(client, message):
    """Auto reply dengan voice note via OpenAI GPT + API TTS lokal Edge-TTS (tanpa delay)."""
    if not message.from_user or message.from_user.id == client.me.id:
        return
    if message.from_user and message.from_user.is_bot:
        return
    if message.voice or message.audio:
        return
    if not message.text or message.text.startswith(("/", ".", "!")):
        return

    chat_id = message.chat.id
    user_id = message.from_user.id
    key = "VNCHAT_AUTO"

    if chat_id not in await dB.get_list_from_var(client.me.id, key):
        return

    query = message.text.strip()
    ROLE_VOICE = (
        "lu adalah manusia dengan karakter jutek dan ngeselin. "
        "balas dengan nada nyolot, pendek, agak toxic, dan pakai huruf kecil semua. "
        "jangan formal, jangan panjang-panjang."
    )

    try:
        await client.send_chat_action(chat_id, enums.ChatAction.RECORD_AUDIO)

        headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": "gpt-3.5-turbo",
            "messages": [
                {"role": "system", "content": ROLE_VOICE},
                {"role": "user", "content": query},
            ],
            "temperature": 0.8,
            "max_tokens": 150,
        }

        async with httpx.AsyncClient() as ses:
            gpt_res = await ses.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=payload,
                timeout=60,
            )

        if gpt_res.status_code != 200:
            logger.warning(f"[AutoVN] Gagal ambil teks dari OpenAI: {gpt_res.status_code}")
            return

        js = gpt_res.json()
        text_reply = (
            js.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
            .strip()
        )

        if not text_reply:
            logger.warning(f"[AutoVN] Tidak ada content dari OpenAI: {js}")
            return

        # 🔊 Ambil model suara per grup
        voice_model = await dB.get_var(client.me.id, f"VNVOICE_{chat_id}") or "id-ID-GadisNeural"

        async with httpx.AsyncClient() as ses:
            tts_res = await ses.post(
                "http://localhost:8000/api/tts",
                json={
                    "text": text_reply,
                    "voice": voice_model,
                    "rate": "10%",
                    "volume": "0%"
                },
                timeout=120,
            )

        if tts_res.status_code != 200:
            logger.warning(f"[AutoVN] Gagal konversi teks ke suara: {tts_res.status_code}")
            return

        filename = f"{uuid.uuid4().hex}.mp3"
        async with aiofiles.open(filename, "wb") as f:
            await f.write(tts_res.content)

        try:
            audio = MutagenFile(filename, easy=True)
            if audio and hasattr(audio, "tags") and audio.tags:
                audio.delete()
                audio.save()
        except ID3NoHeaderError:
            pass
        except Exception as e:
            logger.warning(f"[AutoVN] Metadata clean error: {e}")

        await asyncio.sleep(random.uniform(1.5, 3.0))
        await message.reply_voice(filename)

        try:
            os.remove(filename)
        except Exception:
            pass

    except Exception:
        logger.error(f"[AutoVN Exception] {traceback.format_exc()}")


@CMD.UBOT("vnget")
async def list_voices_cmd(client, message):
    """Menampilkan daftar voice Indonesia dari server TTS lokal"""
    em = Emoji(client)
    await em.get()

    try:
        msg = await message.reply(
            f"<blockquote>{em.proses}Mengambil daftar suara dari server TTS...</blockquote>"
        )

        async with httpx.AsyncClient() as ses:
            res = await ses.get("http://localhost:8000/voices", timeout=30)

        if res.status_code != 200:
            return await msg.edit(
                f"<blockquote>{em.gagal}Gagal mengambil daftar suara.\nStatus: {res.status_code}</blockquote>"
            )

        data = res.json()
        # Hanya ambil voice yang mengandung "id" (bahasa Indonesia)
        voices_raw = [v for v in data.get("voices", []) if "id" in v.lower()]

        if not voices_raw:
            return await msg.edit(
                f"<blockquote>{em.gagal}Tidak ada suara Bahasa Indonesia yang ditemukan.</blockquote>"
            )

        # 🧩 pisahkan blockquote expandable dan petunjuk
        voice_text = "<blockquote expandable><b>🎙️ Daftar Voice Bahasa Indonesia:</b>\n\n"
        for i, v in enumerate(voices_raw[:50], 1):
            voice_text += f"{i}. `{v}`\n"
        voice_text += "</blockquote>"
        voice_text += "\n<blockquote>Gunakan `.setvn su-ID-JajangNeural` untuk memilih suara.</blockquote>"

        await msg.edit(voice_text)

    except Exception as e:
        await message.reply(
            f"<blockquote>{em.gagal}Terjadi error: {e}</blockquote>"
        )


@CMD.UBOT("getvn")
async def get_vnvoice_all(client, message):
    """Melihat semua model suara VN yang tersimpan di setiap grup"""
    em = Emoji(client)
    await em.get()

    msg = await message.reply(
        f"<blockquote>{em.proses}Mengambil daftar voice dari semua grup...</blockquote>"
    )

    try:
        # Ambil semua variabel yang tersimpan
        all_vars = await dB.all_var(client.me.id)
        if not all_vars:
            return await msg.edit(
                f"<blockquote>{em.gagal}Belum ada data variabel VN tersimpan.</blockquote>"
            )

        # Filter hanya yang berawalan VNVOICE_
        vnvoice_keys = {k: v for k, v in all_vars.items() if k.startswith("VNVOICE_")}

        if not vnvoice_keys:
            return await msg.edit(
                f"<blockquote>{em.gagal}Belum ada grup yang memiliki model suara VN.</blockquote>"
            )

        text = "<blockquote expandable><b>🎙️ Daftar Model Voice per Grup:</b>\n\n"
        i = 1
        for key, voice in vnvoice_keys.items():
            try:
                chat_id = int(key.replace("VNVOICE_", ""))
                chat = await client.get_chat(chat_id)
                group_name = chat.title or str(chat_id)
            except Exception:
                group_name = "Unknown Group"
                chat_id = key.replace("VNVOICE_", "")

            text += f"{i}. <b>{group_name}</b> (`{chat_id}`)\n    🔊 <code>{voice}</code>\n"
            i += 1

        text += "</blockquote>"
        await msg.edit(text)

    except Exception as e:
        await msg.edit(
            f"<blockquote>{em.gagal}Terjadi error saat mengambil data: {e}</blockquote>"
        )

@navy.on_message()
async def _(client, message):
    try:
        await auto_vn_reply(client, message)
    except Exception as e:
        logger.error(f"[AutoVN Error] {e}")