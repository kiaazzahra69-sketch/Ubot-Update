from pyrogram import Client, filters
from pyrogram import *
from helpers import Emoji, CMD
from clients import navy

__MODULES__ = "CariUser"
__HELP__ = """<blockquote>Command Help **Cari user**</blockquote>
    
<blockquote><u>**Find user sosial media**</u>
        `{0}cuser`</blockquote>
    
<b>   {1}</b>
"""

IS_PRO = True

@CMD.UBOT("cuser")
async def cek_user_command(client, message, *args):
    # Ambil argumen dari pesan
    args = message.text.split(maxsplit=1)

    if len(args) < 2:
        await message.reply_text(
            "<blockquote><b>⛔ Gunakan format: cuser [username]</b></blockquote>"
        )
        return

    username = args[1]
    platforms = {
        "🔹 GitHub": f"https://github.com/{username}",
        "🔹 Instagram": f"https://www.instagram.com/{username}",
        "🔹 Facebook": f"https://www.facebook.com/{username}",
        "🔹 Twitter/X": f"https://x.com/{username}",
        "🔹 TikTok": f"https://www.tiktok.com/@{username}",
        "🔹 Telegram": f"https://t.me/{username}"
    }

    result_text = f"🔍 **Hasil Pencarian untuk Username:** `{username}`\n\n"
    result_text += "\n".join([f"{platform}: [Klik disini]({link})" for platform, link in platforms.items()])

    await message.reply_text(result_text, disable_web_page_preview=True)
