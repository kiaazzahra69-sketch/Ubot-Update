import requests
from pyrogram import Client, filters
from helpers import Emoji, CMD
from clients import navy

__MODULES__ = "Vcc"
__HELP__ = """<blockquote>Command Help **Vcc**</blockquote>
<blockquote expandable>--**Basic Commands**--

    **Get vcc info from user**
        `{0}vcc` (reply)</blockquote>
<b>   {1}</b>
"""

IS_BASIC = True


@CMD.UBOT("vcc")
async def generate_vcc(client, message, *args):
    em = Emoji(client)
    await em.get()
    API_URL = "https://api.siputzx.my.id/api/tools/vcc-generator"
    params = {
        "type": "MasterCard",
        "count": 1
    }

    # Tampilkan pesan proses
    waiting_msg = await message.reply_text(f"<blockquote>{em.proses} Mengambil data VCC...</blockquote>")

    try:
        response = requests.get(API_URL, params=params)
        data = response.json()

        if data.get("status"):
            vcc_list = data.get("data", [])
            result = "<blockquote expandable>**Generated VCCs:**\n"

            for vcc in vcc_list:
                result += f"\n💳 **Card Number:** `{vcc['cardNumber']}`\n"
                result += f"📅 **Exp Date:** `{vcc['expirationDate']}`\n"
                result += f"👤 **Holder:** `{vcc['cardholderName']}`\n"
                result += f"🔑 **CVV:** `{vcc['cvv']}`\n"
                result += "-------------------------</blockquote>"

            # Hapus pesan proses sebelum mengirim hasil
            await waiting_msg.delete()
            await message.reply_text(result)
        else:
            await waiting_msg.edit_text(f"<blockquote>{em.gagal} Gagal mengambil data VCC.</blockquote>")

    except Exception as e:
        await waiting_msg.edit_text(f"<blockquote>{em.gagal} Terjadi kesalahan: {e}</blockquote>")