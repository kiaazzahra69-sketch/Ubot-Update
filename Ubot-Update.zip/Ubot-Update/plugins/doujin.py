import traceback
from config import API_MAELYN
from helpers import Emoji, CMD, Tools, animate_proses
from logs import logger
from clients import navy


__MODULES__ = "Doujin"
__HELP__ = """<blockquote>Command Help **Doujin**</blockquote>
    
<blockquote><u>**Get Update Doujin**</u>
    <u>**Get DoujinDesu**</u>
        `{0}doujinup`</blockquote>
    
<b>   {1}</b>
"""

IS_PRO = True


# === DoujinDesu Last Update ===
@CMD.UBOT("doujinup")
async def doujin_last_cmd(client, message):
    em = Emoji(client)
    await em.get()
    proses = await animate_proses(message, em.proses)
    try:
        url = "https://api.maelyn.sbs/api/doujindesu/lastupdate"
        result = await Tools.fetch.get(url, headers={"mg-apikey": API_MAELYN})
        if result.status_code != 200:
            return await proses.edit(
                f"<blockquote>{em.gagal}error {result.status_code}</blockquote>"
            )

        data = result.json().get("result", [])
        if not data:
            return await proses.edit(
                f"<blockquote>{em.gagal}ga ada update</blockquote>"
            )

        await proses.delete()

        for i, d in enumerate(data[:2], start=1):  # ambil 2 update terbaru
            title = d.get("title", "no title")
            link = d.get("link", "")
            info = d.get("info", "")
            tipe = d.get("type", "")
            thumb = d.get("thumb", None)

            caption = (
                f"<blockquote expandable><b>{i}. {title}</b>\n"
                f"📖 <b>{info}</b>\n"
                f"📌 <b>Type:</b> {tipe}\n\n"
                f"<a href='{link}'>🔗 Baca disini</a></blockquote>"
            )

            if thumb:
                await message.reply_photo(thumb, caption=caption)
            else:
                await message.reply(caption, disable_web_page_preview=True)

    except Exception as e:
        logger.error(traceback.format_exc())
        return await proses.edit(
            f"<blockquote>{em.gagal}error: {str(e)}</blockquote>"
        )