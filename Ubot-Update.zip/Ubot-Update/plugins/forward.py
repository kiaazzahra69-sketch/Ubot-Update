import asyncio
import os
import traceback
from urllib.parse import urlparse

from pyrogram import enums
from pyrogram.errors import FloodPremiumWait, FloodWait, RPCError

from helpers import CMD, Emoji, Tools, animate_proses
from logs import logger

__MODULES__ = "Ambil"
__HELP__ = """<blockquote>Command Help **Ambil**</blockquote>

<blockquote expandable>    <u>**Copy/Forward media from channel **</u>
<u>**Forward media with delay**</u>
        `{0}ambil` (link)</blockquote>

<b>   {1}</b>
"""
IS_PRO = True

@CMD.UBOT("ambil")
async def _(client, message):
    """Entry point untuk perintah .ambil"""
    return await ambil_cmd(client, message)

async def ambil_cmd(client, message):
    """
    Fungsi utama untuk menyalin media dari channel/grup tertentu.
    
    Format: .ambil <link_pesan> <jumlah>
    Contoh: .ambil https://t.me/c/123456789/100 5
    """
    try:
        em = Emoji(client)
        await em.get()
    except Exception:
        # Fallback jika Emoji gagal dimuat
        class DummyEmoji:
            def __init__(self):
                self.proses = "⏳"
        em = DummyEmoji()

    args = message.command[1:]

    # --- 1. Validasi Argumen Input ---
    if len(args) < 2:
        return await message.reply(
            f"<blockquote>**Mohon berikan tautan dan jumlah!**\nContoh: `{message.text.split()[0]} https://t.me/c/12345/100 5`</blockquote>"
        )

    proses = await animate_proses(message, em.proses)
    chat_id = message.chat.id
    message_link = args[0]

    try:
        total = int(args[1])
    except ValueError:
        return await proses.edit(
            f"<blockquote>**Jumlah harus berupa angka!**\nContoh: `{message.text.split()[0]} https://t.me/c/12345/100 5`</blockquote>"
        )

    # ==========================================================
    # --- MODIFIKASI: Penanganan Tautan Topik/Private Channel ---
    # ==========================================================

    chats = None
    links = None
    try:
        parsed_url = urlparse(message_link)
        path_parts = parsed_url.path.strip('/').split('/')

        # Contoh link: /c/3147426621/57001/107719 (untuk topik)
        if len(path_parts) >= 2 and path_parts[0] in ['c', 's']:
            raw_chat_id = path_parts[1]

            # Konversi Chat ID ke format Pyrogram (-100xxxxxx)
            chats = int(f"-100{raw_chat_id}")

            # Ekstraksi ID Pesan Awal (links)
            if len(path_parts) >= 4:
                # Format Topik: /c/CHAT_ID/TOPIC_ID/MESSAGE_ID
                # Ambil ID Pesan yang sebenarnya
                links = int(path_parts[3]) 
            elif len(path_parts) == 3:
                # Format standar: /c/CHAT_ID/MESSAGE_ID
                links = int(path_parts[2])
            else:
                raise ValueError("Format link private tidak didukung.")

        else:
            # Jika bukan format /c/, biarkan Tools.get_link yang tangani (link publik, username, dll.)
            chats, links = Tools.get_link(message_link)
            if chats is None or links is None:
                raise ValueError("Tautan tidak valid atau Tools.get_link gagal memproses.")

    except Exception as e:
        logger.error(f"Error parsing link: {e} {traceback.format_exc()}")
        return await proses.edit(
            f"<blockquote>**Tautan tidak valid!** Kesalahan parsing: {str(e)}</blockquote>"
        )
    # ==========================================================
    # --- Akhir Modifikasi Penanganan Tautan ---
    # ==========================================================

    try:
        # --- 2. Mendapatkan ID Pesan Terakhir ---
        lastnih = None
        async for msg in client.get_chat_history(chats, limit=1):
            lastnih = msg.id
            break

        if lastnih is None:
            return await proses.edit("<blockquote><b>Tidak ditemukan pesan di obrolan sumber!</b></blockquote>")

        logger.info(f"Source Chat: {chats}, Start ID: {links}, Last ID: {lastnih}, Total Requested: {total}")

        counter = 0
        successful_copies = 0
        skipped_messages = 0

        end_id = min(total + links, lastnih + 1)

        # --- 3. Iterasi dan Salin Pesan (Bagian MODIFIKASI Bypass) ---
        for message_id in range(links, end_id):

            # --- Jeda 3 Detik untuk Mencegah Flood ---
            await asyncio.sleep(3) 
            # ----------------------------------------

            try:
                msg = await client.get_messages(chats, message_id)

                if not msg:
                    skipped_messages += 1
                    continue

                # Filter: Perluas pengecekan media untuk semua jenis media yang dilindungi
                is_media_or_caption = msg.media in [
                    enums.MessageMediaType.VIDEO,
                    enums.MessageMediaType.PHOTO,
                    enums.MessageMediaType.DOCUMENT,
                    enums.MessageMediaType.AUDIO,
                    enums.MessageMediaType.ANIMATION,
                    enums.MessageMediaType.VOICE,
                    enums.MessageMediaType.VIDEO_NOTE,
                ] or msg.caption

                # Lewati pesan teks murni (tanpa media/caption)
                if msg.text and not msg.caption and not is_media_or_caption:
                    skipped_messages += 1
                    continue


                # --- Logika Penyalinan/Pengambilan ---
                try:
                    # 1. Coba Salin Langsung (Metode Cepat)
                    await msg.copy(chat_id)
                    successful_copies += 1
                    counter += 1

                # Penanganan FloodWait saat menyalin
                except (FloodWait, FloodPremiumWait) as wet:
                    logger.warning(f"Copy FloodWait: Waiting for {wet.value} seconds")
                    await asyncio.sleep(wet.value)
                    await msg.copy(chat_id) # Coba lagi
                    successful_copies += 1
                    counter += 1

                # 2. Penanganan Kegagalan (Termasuk Copy Protection/RPC Error) -> Fallback ke Unduh
                except Exception as e_copy:
                    logger.warning(f"Copy failed for message {message_id}: {e_copy}. Trying download (Copy Protection Bypass)...")

                    # Notifikasi Unduhan Sementara
                    cnt = await message.reply(
                        f"<blockquote><b>Gagal menyalin pesan ID {message_id}, mencoba mengunduh (Bypass)...</b></blockquote>"
                    )

                    # Panggil Tools.download_media (HARUS melakukan Unduh lalu Unggah Ulang)
                    
                    # MODIFIKASI DIMULAI DI SINI
                    file_path = None # Inisialisasi path file yang akan diunduh
                    try:
                        # Tools.download_media HARUS mengembalikan jalur file yang diunduh
                        file_path = await Tools.download_media(msg, client, cnt, message)
                        
                        successful_copies += 1
                        counter += 1
                        await cnt.delete() # Hapus notifikasi
                        
                    except Exception as e_download:
                        logger.error(f"Download/Upload failed for message {message_id}: {e_download}")
                        await cnt.edit(f"<blockquote><b>Gagal mengambil pesan ID {message_id} (Copy & Download gagal).</b></blockquote>")
                        skipped_messages += 1
                        await asyncio.sleep(3)
                        await cnt.delete()
                        
                    finally:
                        # PENTING: Hapus file lokal di VPS
                        if file_path and os.path.exists(file_path):
                            try:
                                os.remove(file_path)
                                logger.info(f"File sementara ID {message_id} berhasil dihapus: {file_path}")
                            except Exception as e_del:
                                logger.error(f"Gagal menghapus file {file_path}: {e_del}")
                    # MODIFIKASI BERAKHIR DI SINI


            # Penanganan FloodWait saat get_messages
            except (FloodWait, FloodPremiumWait) as flood:
                logger.error(f"GetMessages FloodWait: Waiting for {flood.value} seconds")
                await asyncio.sleep(flood.value)
                # Lanjutkan loop, pesan akan dicoba lagi setelah jeda

            # Penanganan Kesalahan Pyrogram RPC lainnya (saat get_messages)
            except RPCError as rpc_error:
                logger.error(f"RPC Error getting message {message_id}: {rpc_error}. Skipping.")
                skipped_messages += 1
                continue

            # Penanganan Kesalahan Umum lainnya
            except Exception as er:
                logger.error(f"Error processing message {message_id}: {traceback.format_exc()}")
                skipped_messages += 1
                continue

        # --- 4. Pelaporan Hasil ---
        await proses.delete()
        return await message.reply(
            f"<blockquote><b>Penyalinan selesai. 🎉\n"
            f"Total pesan yang dicoba: {total}\n"
            f"Berhasil disalin: {successful_copies}\n"
            f"Pesan dilewati/gagal: {skipped_messages}</b></blockquote>"
        )

    except Exception as e:
        logger.error(f"Overall process error: {traceback.format_exc()}")
        await proses.delete()
        return await message.reply(f"<blockquote>Terjadi kesalahan tak terduga: {str(e)}</blockquote>")
