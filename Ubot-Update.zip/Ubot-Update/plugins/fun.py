import random

from helpers import Emoji, CMD, animate_proses
from clients import navy 

__MODULES__ = "Gben"
__HELP__ = """<blockquote>Command Help **Global ben**</blockquote>
    
<blockquote><u>**Fun global banned and fake transaction**</u>
        `{0}gben`
        `{0}gmut`
        `{0}gkik`
        `{0}ftf`</blockquote>
    
<b>   {1}</b>
"""

IS_PRO = True


@CMD.UBOT("gben")
async def gben_cmd(client, message):
    em = Emoji(client)
    await em.get()
    pros = await animate_proses(message, em.proses)
    try:
        if len(message.command) > 1:
            pengguna, alasan = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            sukses = random.randint(80, 800)
            gagal = random.randint(1, 20)
            report_message = (
                f"{em.warn}<b>Laporan Global Banned :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Sukses : `{sukses}` grup.</b>\n"
                f"{em.gagal}<b>Gagal : `{gagal}` grup.</b>"
            )
            if alasan:
                report_message += f"\n\n<b>{em.block}Alasan : `{alasan}`</b>"
            return await pros.edit(report_message)
        else:
            pengguna, alasan = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            sukses = random.randint(80, 800)
            gagal = random.randint(1, 20)
            report_message = (
                f"{em.warn}<b>Laporan Global Banned :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Sukses : `{sukses}` grup.</b>\n"
                f"{em.gagal}<b>Gagal : `{gagal}` grup.</b>"
            )
            return await pros.edit(report_message)
    except Exception as e:
        return await pros.edit(
            f"<blockquote>{em.gagal}Gagal membuat laporan Global Banned: {str(e)}</blockquote>"
        )


@CMD.UBOT("gmut")
async def gmut_cmd(client, message):
    em = Emoji(client)
    await em.get()
    pros = await animate_proses(message, em.proses)
    try:
        if len(message.command) > 1:
            pengguna, alasan = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            sukses = random.randint(80, 800)
            gagal = random.randint(1, 20)
            report_message = (
                f"{em.warn}<b>Laporan Global Mute :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Sukses : `{sukses}` grup.</b>\n"
                f"{em.gagal}<b>Gagal : `{gagal}` grup.</b>"
            )
            if alasan:
                report_message += f"\n\n<b>{em.block}Alasan : `{alasan}`</b>"
            return await pros.edit(report_message)
        else:
            pengguna, alasan = await client.extract_user_and_reason(message)
            mention = (await clinet.get_users(pengguna)).mention
            sukses = random.randint(80, 800)
            gagal = random.randint(1, 20)
            report_message = (
                f"{em.warn}<b>Laporan Global Mute :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Sukses : `{sukses}` grup.</b>\n"
                f"{em.gagal}<b>Gagal : `{gagal}` grup.</b>"
            )
            return await pros.edit(report_message)
    except Exception as e:
        return await pros.edit(f"<blockquote>{em.gagal}Gagal membuat laporan Global Mute: {str(e)}</blockquote>")


@CMD.UBOT("gkik")
async def gkik_cmd(client, message):
    em = Emoji(client)
    await em.get()

    pros = await animate_proses(message, em.proses)
    try:
        if len(message.command) > 1:
            pengguna, alasan = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            sukses = random.randint(80, 800)
            gagal = random.randint(1, 20)
            report_message = (
                f"{em.warn}<b>Laporan Global Kick :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Sukses : `{sukses}` grup.</b>\n"
                f"{em.gagal}<b>Gagal : `{gagal}` grup.</b>"
            )
            if alasan:
                report_message += f"\n<b>{em.block}Alasan : `{alasan}`</b>"
            return await pros.edit(report_message)
        else:
            pengguna, alasan = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            sukses = random.randint(80, 800)
            gagal = random.randint(1, 20)
            report_message = (
                f"{em.warn}<b>Laporan Global Kick :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Sukses : `{sukses}` grup.</b>\n"
                f"{em.gagal}<b>Gagal : `{gagal}` grup.</b>"
            )
            if alasan:
                report_message += f"\n<b>{em.block}Alasan : `{alasan}`</b>"
            return await pros.edit(report_message)
    except Exception as e:
        return await pros.edit(f"<blockquote>{em.gagal}Gagal membuat laporan Global Kick: {str(e)}</blockquote>")


@CMD.UBOT("ftf")
async def ftf_cmd(client, message):
    em = Emoji(client)
    await em.get()

    pros = await animate_proses(message, em.proses)
    try:
        rep = m.reply_to_message
        if not rep and len(message.command) < 2:
            await pros.edit(
                f"{em.gagal}Mohon balas pesan pengguna atau berikan username dan nominal sebagai argumen."
            )
            return

        if rep:
            nominal = (
                message.command[1].replace(".", "")
                if len(message.command) > 1
                else str(random.randint(100000, 50000000))
            )
            pengguna, _ = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            formatted_nominal = "{:,.0f}".format(int(nominal)).replace(",", ".")
            report_message = (
                f"{em.warn}<b>Laporan Transfer :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Nominal : Rp {formatted_nominal},-</b>\n"
            )
            return await pros.edit(report_message)
        else:
            nominal = message.command[1].replace(".", "")
            pengguna, _ = await client.extract_user_and_reason(message)
            mention = (await client.get_users(pengguna)).mention
            formatted_nominal = "{:,.0f}".format(int(nominal)).replace(",", ".")
            report_message = (
                f"{em.warn}<b>Laporan Transfer :</b>\n\n"
                f"{em.profil}<b>Pengguna : {mention}</b>\n"
                f"{em.sukses}<b>Nominal : Rp {formatted_nominal},-</b>\n"
            )
            return await pros.edit(report_message)
    except Exception as e:
        return await pros.edit(f"<blockquote>{em.gagal}Gagal membuat laporan Transfer: {str(e)}</blockquote>")