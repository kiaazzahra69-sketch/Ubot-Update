import random
from pyrogram.enums import MessagesFilter
from helpers import *
from helpers import CMD, Emoji

__MODULES__ = "Vip indo"
__HELP__ = """<blockquote>Command Help **Vipindo**
    
<blockquote>**Get videos**
    **Get random vipindo video command**
        `{0}vipindo`</blockquote>
    
<b>   {1}</b>
"""
IS_BASIC = True

@CMD.UBOT("vipindo")
async def video_asupan(client, message):
    y = await message.reply_text(f"jangan ngocok mulu dek....")
    try:
        asupannya = []
        async for asupan in client.search_messages(
            "@vvideo_viral", filter=MessagesFilter.VIDEO
        ):
            asupannya.append(asupan)
        video = random.choice(asupannya)
        await video.copy(message.chat.id, reply_to_message_id=message.id)
        await y.delete()
    except Exception as error:
        await y.edit(error)
